package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NewMatchScreen
import com.example.ui.screens.ScoringScreen
import com.example.ui.screens.SpectatorScreen
import com.example.ui.theme.CricScoreTheme
import com.example.viewmodel.CricketViewModel

enum class AppScreen {
    HOME,
    SCORING,
    NEW_MATCH,
    SPECTATOR
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CricScoreTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CricScoreApp()
                }
            }
        }
    }
}

@Composable
fun CricScoreApp(viewModel: CricketViewModel = viewModel()) {
    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }

    when (currentScreen) {
        AppScreen.HOME -> HomeScreen(
            viewModel = viewModel,
            onNavigateToScoring = { matchId ->
                viewModel.selectMatch(matchId)
                currentScreen = AppScreen.SCORING
            },
            onNavigateToNewMatch = {
                currentScreen = AppScreen.NEW_MATCH
            },
            onNavigateToSpectator = {
                currentScreen = AppScreen.SPECTATOR
            }
        )

        AppScreen.SCORING -> ScoringScreen(
            viewModel = viewModel,
            onBack = {
                viewModel.clearSelectedMatch()
                currentScreen = AppScreen.HOME
            }
        )

        AppScreen.NEW_MATCH -> NewMatchScreen(
            viewModel = viewModel,
            onBack = {
                currentScreen = AppScreen.HOME
            },
            onMatchCreated = { matchId ->
                viewModel.selectMatch(matchId)
                currentScreen = AppScreen.SCORING
            }
        )

        AppScreen.SPECTATOR -> SpectatorScreen(
            viewModel = viewModel,
            onBack = {
                viewModel.clearSelectedMatch()
                currentScreen = AppScreen.HOME
            },
            onWatchMatch = { matchId ->
                viewModel.selectMatch(matchId)
                // Remains in spectator screen showing the match
            }
        )
    }
}
