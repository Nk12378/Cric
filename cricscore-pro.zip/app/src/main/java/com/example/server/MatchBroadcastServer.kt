package com.example.server

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.example.data.model.FullMatchState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.Locale

class MatchBroadcastServer {

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var port: Int = 8080

    @Volatile
    private var currentMatchState: FullMatchState? = null

    val isRunning: Boolean
        get() = serverSocket != null && !serverSocket!!.isClosed

    fun updateState(state: FullMatchState) {
        currentMatchState = state
    }

    fun start(scope: CoroutineScope, preferredPort: Int = 8080): Int {
        if (isRunning) return port

        port = preferredPort
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                // Try preferred port, fallback to next ports if busy
                for (p in preferredPort..(preferredPort + 5)) {
                    try {
                        serverSocket = ServerSocket(p)
                        port = p
                        Log.i("BroadcastServer", "Spectator broadcast server started on port $port")
                        break
                    } catch (e: Exception) {
                        Log.w("BroadcastServer", "Port $p occupied, trying next")
                    }
                }

                val socket = serverSocket ?: return@launch

                while (isActive && !socket.isClosed) {
                    try {
                        val client: Socket = socket.accept()
                        handleClient(client)
                    } catch (e: Exception) {
                        if (!isActive || socket.isClosed) break
                        Log.e("BroadcastServer", "Error accepting client", e)
                    }
                }
            } catch (e: Exception) {
                Log.e("BroadcastServer", "Failed to launch server", e)
            }
        }
        return port
    }

    fun stop() {
        try {
            serverSocket?.close()
            serverSocket = null
            serverJob?.cancel()
            serverJob = null
            Log.i("BroadcastServer", "Spectator broadcast server stopped")
        } catch (e: Exception) {
            Log.e("BroadcastServer", "Error stopping server", e)
        }
    }

    private fun handleClient(client: Socket) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                client.use { s ->
                    val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                    val line = reader.readLine() ?: return@launch
                    val parts = line.split(" ")
                    val path = if (parts.size > 1) parts[1] else "/"

                    val writer = PrintWriter(s.getOutputStream(), true)

                    if (path.startsWith("/api/match")) {
                        val json = generateJsonFeed(currentMatchState)
                        writer.println("HTTP/1.1 200 OK")
                        writer.println("Content-Type: application/json; charset=UTF-8")
                        writer.println("Access-Control-Allow-Origin: *")
                        writer.println("Content-Length: ${json.toByteArray().size}")
                        writer.println("Connection: close")
                        writer.println()
                        writer.print(json)
                        writer.flush()
                    } else {
                        val html = generateSpectatorHtml(currentMatchState)
                        val bytes = html.toByteArray(Charsets.UTF_8)
                        writer.println("HTTP/1.1 200 OK")
                        writer.println("Content-Type: text/html; charset=UTF-8")
                        writer.println("Content-Length: ${bytes.size}")
                        writer.println("Connection: close")
                        writer.println()
                        writer.print(html)
                        writer.flush()
                    }
                }
            } catch (e: Exception) {
                Log.e("BroadcastServer", "Error serving client", e)
            }
        }
    }

    private fun generateJsonFeed(state: FullMatchState?): String {
        if (state == null) {
            return """{"status": "WAITING_FOR_MATCH", "message": "No live match active"}"""
        }
        val match = state.match
        val inn = state.currentInningsSummary

        val recent = state.recentBalls.joinToString(",") { b ->
            val badge = if (b.isWicket) "W" else when (b.extraType) {
                "WIDE" -> "${b.extraRuns}wd"
                "NO_BALL" -> "${b.runsScored + b.extraRuns}nb"
                "BYE" -> "${b.extraRuns}b"
                "LEG_BYE" -> "${b.extraRuns}lb"
                else -> "${b.runsScored}"
            }
            """{"over":${b.overNumber},"ball":${b.ballInOver},"text":"$badge","runs":${b.runsScored + b.extraRuns},"isWicket":${b.isWicket},"commentary":"${escapeJson(b.commentary)}","shot":"${b.shotZone}"}"""
        }

        return """{
            "matchCode": "${match.matchCode}",
            "matchTitle": "${escapeJson(match.matchTitle)}",
            "teamA": "${escapeJson(match.teamAName)}",
            "teamB": "${escapeJson(match.teamBName)}",
            "status": "${match.status}",
            "innings": ${match.currentInnings},
            "battingTeam": "${escapeJson(inn.battingTeam)}",
            "bowlingTeam": "${escapeJson(inn.bowlingTeam)}",
            "totalRuns": ${inn.totalRuns},
            "wickets": ${inn.wickets},
            "overs": "${inn.oversFormatted}",
            "crr": "${inn.currentRunRateFormatted}",
            "target": ${state.target},
            "runsNeeded": ${state.runsNeeded},
            "ballsRemaining": ${state.ballsRemaining},
            "rrr": "${String.format(Locale.US, "%.2f", state.requiredRunRate)}",
            "equation": "${escapeJson(state.equationText)}",
            "striker": "${escapeJson(state.strikerStats?.name ?: "-")}",
            "strikerRuns": ${state.strikerStats?.runs ?: 0},
            "strikerBalls": ${state.strikerStats?.balls ?: 0},
            "nonStriker": "${escapeJson(state.nonStrikerStats?.name ?: "-")}",
            "nonStrikerRuns": ${state.nonStrikerStats?.runs ?: 0},
            "nonStrikerBalls": ${state.nonStrikerStats?.balls ?: 0},
            "bowler": "${escapeJson(state.currentBowlerStats?.name ?: "-")}",
            "bowlerOvers": "${state.currentBowlerStats?.oversFormatted ?: "0.0"}",
            "bowlerRuns": ${state.currentBowlerStats?.runsConceded ?: 0},
            "bowlerWickets": ${state.currentBowlerStats?.wickets ?: 0},
            "recentBalls": [$recent]
        }""".trimIndent()
    }

    private fun generateSpectatorHtml(state: FullMatchState?): String {
        val title = state?.match?.matchTitle ?: "CricScore Pro - Live Spectator"
        val teamA = state?.match?.teamAName ?: "Team 1"
        val teamB = state?.match?.teamBName ?: "Team 2"
        val batting = state?.currentInningsSummary?.battingTeam ?: teamA
        val score = "${state?.currentInningsSummary?.totalRuns ?: 0}/${state?.currentInningsSummary?.wickets ?: 0}"
        val overs = state?.currentInningsSummary?.oversFormatted ?: "0.0"
        val crr = state?.currentInningsSummary?.currentRunRateFormatted ?: "0.00"
        val eq = state?.equationText ?: ""

        val striker = state?.strikerStats?.name ?: "-"
        val sRuns = state?.strikerStats?.runs ?: 0
        val sBalls = state?.strikerStats?.balls ?: 0
        val nonStriker = state?.nonStrikerStats?.name ?: "-"
        val nsRuns = state?.nonStrikerStats?.runs ?: 0
        val nsBalls = state?.nonStrikerStats?.balls ?: 0
        val bowler = state?.currentBowlerStats?.name ?: "-"
        val bOvers = state?.currentBowlerStats?.oversFormatted ?: "0.0"
        val bRuns = state?.currentBowlerStats?.runsConceded ?: 0
        val bWkts = state?.currentBowlerStats?.wickets ?: 0

        val recentBadges = state?.recentBalls?.takeLast(8)?.joinToString("") { b ->
            val txt = if (b.isWicket) "W" else when (b.extraType) {
                "WIDE" -> "${b.extraRuns}wd"
                "NO_BALL" -> "${b.runsScored + b.extraRuns}nb"
                "BYE" -> "${b.extraRuns}b"
                "LEG_BYE" -> "${b.extraRuns}lb"
                else -> "${b.runsScored}"
            }
            val bg = when {
                b.isWicket -> "#d32f2f"
                b.runsScored == 6 -> "#7b1fa2"
                b.runsScored == 4 -> "#1976d2"
                b.runsScored > 0 -> "#388e3c"
                b.extraType != "NONE" -> "#f57c00"
                else -> "#455a64"
            }
            """<span style="display:inline-block;width:34px;height:34px;line-height:34px;text-align:center;border-radius:50%;background:$bg;color:#fff;font-weight:bold;margin:2px;font-size:13px;">$txt</span>"""
        } ?: ""

        return """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>$title - Live Match</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
                body { background: #0B1118; color: #FFFFFF; min-height: 100vh; padding: 16px; }
                .container { max-width: 600px; margin: 0 auto; }
                .header-card { background: linear-gradient(135deg, #0F3E7A, #1B2838); border-radius: 16px; padding: 20px; box-shadow: 0 8px 24px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1); }
                .live-badge { display: inline-flex; align-items: center; background: #D32F2F; color: #fff; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 800; letter-spacing: 1px; }
                .dot { width: 8px; height: 8px; background: #fff; border-radius: 50%; margin-right: 6px; animation: pulse 1s infinite alternate; }
                @keyframes pulse { from { opacity: 0.3; } to { opacity: 1; } }
                .title { font-size: 14px; color: #FFB300; margin-top: 8px; font-weight: 600; text-transform: uppercase; }
                .teams { font-size: 18px; font-weight: 700; margin-top: 4px; }
                .score-row { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 16px; }
                .score { font-size: 44px; font-weight: 900; color: #FFFFFF; letter-spacing: -1px; }
                .overs { font-size: 20px; color: #CBD5E1; margin-left: 8px; }
                .crr { font-size: 13px; color: #94A3B8; text-align: right; }
                .equation { background: rgba(255, 179, 0, 0.15); border-left: 4px solid #FFB300; padding: 8px 12px; margin-top: 14px; border-radius: 4px; font-size: 13px; font-weight: 600; color: #FFD54F; }
                .card { background: #151F2C; border-radius: 14px; padding: 16px; margin-top: 14px; border: 1px solid rgba(255,255,255,0.06); }
                .card-title { font-size: 12px; text-transform: uppercase; color: #94A3B8; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 10px; }
                .crease-row { display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
                .name { font-weight: 600; font-size: 15px; }
                .stats { font-weight: 700; color: #FFB300; }
                .recent-balls { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 8px; }
                .footer { text-align: center; font-size: 11px; color: #64748B; margin-top: 24px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header-card">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span class="live-badge"><span class="dot"></span>LIVE SPECTATOR</span>
                        <span style="font-size:12px; color:#94A3B8;">Code: ${state?.match?.matchCode ?: "MATCH"}</span>
                    </div>
                    <div class="title">$title</div>
                    <div class="teams">$teamA vs $teamB</div>
                    <div class="score-row">
                        <div>
                            <span class="score" id="score-text">$score</span>
                            <span class="overs" id="overs-text">($overs ov)</span>
                        </div>
                        <div class="crr">
                            <div>$batting Batting</div>
                            <div style="margin-top:2px;">CRR: <span id="crr-text">$crr</span></div>
                        </div>
                    </div>
                    ${if (eq.isNotBlank()) "<div class=\"equation\" id=\"eq-text\">$eq</div>" else ""}
                </div>

                <div class="card">
                    <div class="card-title">Batsmen on Crease</div>
                    <div class="crease-row">
                        <span class="name"><span style="color:#FFB300;">*</span> <span id="striker-name">$striker</span></span>
                        <span class="stats" id="striker-stats">$sRuns ($sBalls)</span>
                    </div>
                    <div class="crease-row">
                        <span class="name"><span id="non-striker-name">$nonStriker</span></span>
                        <span class="stats" id="non-striker-stats">$nsRuns ($nsBalls)</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-title">Current Bowler</div>
                    <div class="crease-row">
                        <span class="name" id="bowler-name">$bowler</span>
                        <span class="stats" id="bowler-stats">$bWkts-$bRuns ($bOvers ov)</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-title">Recent Timeline</div>
                    <div class="recent-balls" id="recent-balls-container">$recentBadges</div>
                </div>

                <div class="footer">
                    CricScore Pro Real-Time Broadcast • Auto-updating live match feed
                </div>
            </div>

            <script>
                // Live auto refresh every 2 seconds
                setInterval(function() {
                    fetch('/api/match')
                        .then(r => r.json())
                        .then(data => {
                            if (!data || data.status === 'WAITING_FOR_MATCH') return;
                            document.getElementById('score-text').innerText = data.totalRuns + '/' + data.wickets;
                            document.getElementById('overs-text').innerText = '(' + data.overs + ' ov)';
                            document.getElementById('crr-text').innerText = data.crr;
                            if (document.getElementById('eq-text')) {
                                document.getElementById('eq-text').innerText = data.equation;
                            }
                            document.getElementById('striker-name').innerText = data.striker;
                            document.getElementById('striker-stats').innerText = data.strikerRuns + ' (' + data.strikerBalls + ')';
                            document.getElementById('non-striker-name').innerText = data.nonStriker;
                            document.getElementById('non-striker-stats').innerText = data.nonStrikerRuns + ' (' + data.nonStrikerBalls + ')';
                            document.getElementById('bowler-name').innerText = data.bowler;
                            document.getElementById('bowler-stats').innerText = data.bowlerWickets + '-' + data.bowlerRuns + ' (' + data.bowlerOvers + ' ov)';

                            if (data.recentBalls && data.recentBalls.length > 0) {
                                let html = '';
                                data.recentBalls.slice(-8).forEach(b => {
                                    let bg = b.isWicket ? '#d32f2f' : (b.runs === 6 ? '#7b1fa2' : (b.runs === 4 ? '#1976d2' : (b.runs > 0 ? '#388e3c' : '#455a64')));
                                    html += '<span style="display:inline-block;width:34px;height:34px;line-height:34px;text-align:center;border-radius:50%;background:' + bg + ';color:#fff;font-weight:bold;margin:2px;font-size:13px;">' + b.text + '</span>';
                                });
                                document.getElementById('recent-balls-container').innerHTML = html;
                            }
                        })
                        .catch(err => console.log('Polling...', err));
                }, 2000);
            </script>
        </body>
        </html>
        """.trimIndent()
    }

    private fun escapeJson(str: String): String {
        return str.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
    }

    companion object {
        fun getDeviceIpAddress(): String {
            try {
                val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
                for (intf in interfaces) {
                    val addrs = Collections.list(intf.inetAddresses)
                    for (addr in addrs) {
                        if (!addr.isLoopbackAddress) {
                            val sAddr = addr.hostAddress ?: ""
                            val isIPv4 = sAddr.indexOf(':') < 0
                            if (isIPv4 && (sAddr.startsWith("192.168.") || sAddr.startsWith("10.") || sAddr.startsWith("172."))) {
                                return sAddr
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("BroadcastServer", "Error getting IP", e)
            }
            return "192.168.43.1" // Common hotspot fallback
        }
    }
}
