package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CricScoreDatabase
import com.example.data.local.MatchEntity
import com.example.data.local.PlayerEntity
import com.example.data.local.TournamentEntity
import com.example.data.model.FullMatchState
import com.example.data.repository.CricketRepository
import com.example.server.MatchBroadcastServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalCoroutinesApi::class)
class CricketViewModel(application: Application) : AndroidViewModel(application) {

    private val db = CricScoreDatabase.getInstance(application)
    private val repository = CricketRepository(db.cricScoreDao())
    private val broadcastServer = MatchBroadcastServer()

    val allMatches: StateFlow<List<MatchEntity>> = repository.allMatchesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveMatches: StateFlow<List<MatchEntity>> = repository.liveMatchesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTournaments: StateFlow<List<TournamentEntity>> = repository.allTournamentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedMatchId = MutableStateFlow<String?>(null)
    val selectedMatchId: StateFlow<String?> = _selectedMatchId.asStateFlow()

    val currentMatchState: StateFlow<FullMatchState?> = _selectedMatchId
        .flatMapLatest { id ->
            if (id == null) flowOf(null)
            else repository.getFullMatchStateFlow(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Broadcast Server state
    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _serverUrl = MutableStateFlow("")
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    // Spectator Mode Search state
    private val _spectatorErrorMessage = MutableStateFlow<String?>(null)
    val spectatorErrorMessage: StateFlow<String?> = _spectatorErrorMessage.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.seedInitialDataIfEmpty()
        }

        // Keep broadcast server updated with current match state
        viewModelScope.launch {
            currentMatchState.collect { state ->
                if (state != null && broadcastServer.isRunning) {
                    broadcastServer.updateState(state)
                }
            }
        }
    }

    fun selectMatch(matchId: String) {
        _selectedMatchId.value = matchId
    }

    fun clearSelectedMatch() {
        _selectedMatchId.value = null
    }

    fun startBroadcastServer(matchId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val port = broadcastServer.start(viewModelScope)
            val ip = MatchBroadcastServer.getDeviceIpAddress()
            _serverUrl.value = "http://$ip:$port/live"
            _isServerRunning.value = true

            currentMatchState.value?.let {
                broadcastServer.updateState(it)
            }
        }
    }

    fun stopBroadcastServer() {
        broadcastServer.stop()
        _isServerRunning.value = false
        _serverUrl.value = ""
    }

    fun recordBall(
        runs: Int,
        extraType: String,
        extraRuns: Int,
        isWicket: Boolean,
        wicketType: String,
        fielder: String = "",
        shotZone: String = "STRAIGHT",
        newBatter: String = "",
        commentary: String = ""
    ) {
        val matchId = _selectedMatchId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.recordBall(
                matchId = matchId,
                runsScored = runs,
                extraType = extraType,
                extraRuns = extraRuns,
                isWicket = isWicket,
                wicketType = wicketType,
                fielderName = fielder,
                shotZone = shotZone,
                newBatsmanName = newBatter,
                customCommentary = commentary
            )
        }
    }

    fun undoLastBall() {
        val matchId = _selectedMatchId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.undoLastBall(matchId)
        }
    }

    fun swapStrike() {
        val matchId = _selectedMatchId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.swapStrike(matchId)
        }
    }

    fun setBowler(bowlerName: String) {
        val matchId = _selectedMatchId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.setBowler(matchId, bowlerName)
        }
    }

    fun startMatch(
        matchId: String,
        tossWinner: String,
        tossDecision: String,
        striker: String,
        nonStriker: String,
        openingBowler: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.startMatch(matchId, tossWinner, tossDecision, striker, nonStriker, openingBowler)
        }
    }

    fun startSecondInnings(
        matchId: String,
        striker: String,
        nonStriker: String,
        openingBowler: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.startSecondInnings(matchId, striker, nonStriker, openingBowler)
        }
    }

    fun createMatch(
        tournamentId: String,
        matchTitle: String,
        teamA: String,
        teamB: String,
        teamAShort: String,
        teamBShort: String,
        overs: Int,
        maxOversPerBowler: Int,
        teamAPlayers: List<String>,
        teamBPlayers: List<String>,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = repository.createMatch(
                tournamentId = tournamentId,
                matchTitle = matchTitle,
                teamAName = teamA,
                teamBName = teamB,
                teamAShort = teamAShort,
                teamBShort = teamBShort,
                overs = overs,
                maxOversPerBowler = maxOversPerBowler,
                teamAPlayers = teamAPlayers,
                teamBPlayers = teamBPlayers
            )
            withContext(Dispatchers.Main) {
                _selectedMatchId.value = id
                onSuccess(id)
            }
        }
    }

    fun createTournament(name: String, season: String, venue: String, onComplete: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = repository.createTournament(name, season, venue)
            withContext(Dispatchers.Main) {
                onComplete(id)
            }
        }
    }

    suspend fun getPlayersForMatch(matchId: String): List<PlayerEntity> {
        return repository.getPlayersForMatch(matchId)
    }

    fun findMatchByCode(code: String, onFound: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val match = repository.getMatchByCode(code)
            withContext(Dispatchers.Main) {
                if (match != null) {
                    _spectatorErrorMessage.value = null
                    _selectedMatchId.value = match.id
                    onFound(match.id)
                } else {
                    _spectatorErrorMessage.value = "No match found with code: $code"
                }
            }
        }
    }

    fun clearSpectatorError() {
        _spectatorErrorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        broadcastServer.stop()
    }
}
