package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "balls",
    indices = [
        Index(value = ["matchId", "innings"]),
        Index(value = ["matchId", "timestamp"])
    ]
)
data class BallEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val matchId: String,
    val innings: Int,
    val overNumber: Int,
    val ballInOver: Int,
    val isLegalBall: Boolean,
    val batsmanName: String,
    val bowlerName: String,
    val nonStrikerName: String,
    val runsScored: Int,
    val extraType: String,
    val extraRuns: Int,
    val isWicket: Boolean,
    val wicketType: String,
    val dismissedPlayerName: String,
    val fielderName: String = "",
    val shotZone: String = "STRAIGHT",
    val commentary: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
