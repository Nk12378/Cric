package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tournaments")
data class TournamentEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val season: String = "2026",
    val venue: String = "Main Ground",
    val bannerUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
