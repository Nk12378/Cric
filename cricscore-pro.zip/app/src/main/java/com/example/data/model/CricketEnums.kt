package com.example.data.model

enum class MatchStatus {
    UPCOMING,
    LIVE_INNINGS_1,
    INNINGS_BREAK,
    LIVE_INNINGS_2,
    COMPLETED
}

enum class TossDecision {
    BAT,
    BOWL
}

enum class ExtraType {
    NONE,
    WIDE,
    NO_BALL,
    BYE,
    LEG_BYE,
    PENALTY
}

enum class WicketType {
    NONE,
    BOWLED,
    CAUGHT,
    LBW,
    RUN_OUT,
    STUMPED,
    HIT_WICKET,
    RETIRED_HURT,
    OBSTRUCTING_FIELD
}

enum class ShotZone(val displayName: String, val angleDegrees: Float) {
    STRAIGHT("Straight Down Ground", 0f),
    LONG_OFF("Long Off", 40f),
    COVER("Extra Cover", 80f),
    POINT("Point / Backward Point", 120f),
    THIRD_MAN("Third Man", 155f),
    FINE_LEG("Fine Leg", 205f),
    SQUARE_LEG("Square Leg", 240f),
    MID_WICKET("Deep Mid-Wicket", 280f),
    LONG_ON("Long On", 320f)
}
