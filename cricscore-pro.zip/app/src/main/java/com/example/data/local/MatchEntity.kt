package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey
    val id: String,
    val tournamentId: String,
    val matchTitle: String = "Match",
    val teamAName: String,
    val teamBName: String,
    val teamAShort: String,
    val teamBShort: String,
    val overs: Int = 20,
    val maxOversPerBowler: Int = 4,
    val tossWinnerTeam: String = "",
    val tossDecision: String = "BAT",
    val battingFirstTeam: String = "",
    val bowlingFirstTeam: String = "",
    val status: String = "UPCOMING",
    val currentInnings: Int = 1,
    val strikerName: String = "",
    val nonStrikerName: String = "",
    val currentBowlerName: String = "",
    val previousBowlerName: String = "",
    val target: Int = 0,
    val winner: String = "",
    val winDescription: String = "",
    val matchCode: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
