package com.example.data.model

import com.example.data.local.BallEntity
import com.example.data.local.MatchEntity
import java.util.Locale

data class BatsmanInningsStats(
    val name: String,
    val runs: Int = 0,
    val balls: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    val dismissal: String = "not out",
    val isOut: Boolean = false,
    val isBatting: Boolean = false
) {
    val strikeRate: Double
        get() = if (balls > 0) (runs.toDouble() / balls * 100.0) else 0.0

    val strikeRateFormatted: String
        get() = String.format(Locale.US, "%.1f", strikeRate)
}

data class BowlerInningsStats(
    val name: String,
    val legalBalls: Int = 0,
    val maidens: Int = 0,
    val runsConceded: Int = 0,
    val wickets: Int = 0,
    val dots: Int = 0
) {
    val oversFormatted: String
        get() {
            val fullOvers = legalBalls / 6
            val balls = legalBalls % 6
            return "$fullOvers.$balls"
        }

    val oversDouble: Double
        get() = (legalBalls / 6) + (legalBalls % 6) / 6.0

    val economy: Double
        get() = if (oversDouble > 0) runsConceded / oversDouble else 0.0

    val economyFormatted: String
        get() = String.format(Locale.US, "%.2f", economy)
}

data class FallOfWicket(
    val wicketNumber: Int,
    val teamScore: Int,
    val overFormatted: String,
    val batsmanName: String
)

data class ExtrasSummary(
    val wides: Int = 0,
    val noBalls: Int = 0,
    val byes: Int = 0,
    val legByes: Int = 0,
    val penalty: Int = 0
) {
    val total: Int
        get() = wides + noBalls + byes + legByes + penalty
}

data class InningsScoreSummary(
    val innings: Int,
    val battingTeam: String,
    val bowlingTeam: String,
    val totalRuns: Int = 0,
    val wickets: Int = 0,
    val legalBalls: Int = 0,
    val extras: ExtrasSummary = ExtrasSummary(),
    val batters: List<BatsmanInningsStats> = emptyList(),
    val bowlers: List<BowlerInningsStats> = emptyList(),
    val fallOfWickets: List<FallOfWicket> = emptyList(),
    val currentOverBalls: List<BallEntity> = emptyList(),
    val overRunsList: List<Int> = emptyList(),
    val cumulativeRunsList: List<Int> = emptyList(),
    val currentPartnershipRuns: Int = 0,
    val currentPartnershipBalls: Int = 0
) {
    val oversFormatted: String
        get() {
            val full = legalBalls / 6
            val rem = legalBalls % 6
            return "$full.$rem"
        }

    val oversDouble: Double
        get() = (legalBalls / 6) + (legalBalls % 6) / 6.0

    val currentRunRate: Double
        get() = if (oversDouble > 0) totalRuns / oversDouble else 0.0

    val currentRunRateFormatted: String
        get() = String.format(Locale.US, "%.2f", currentRunRate)
}

data class FullMatchState(
    val match: MatchEntity,
    val innings1Summary: InningsScoreSummary,
    val innings2Summary: InningsScoreSummary?,
    val currentInningsSummary: InningsScoreSummary,
    val recentBalls: List<BallEntity> = emptyList(),
    val strikerStats: BatsmanInningsStats? = null,
    val nonStrikerStats: BatsmanInningsStats? = null,
    val currentBowlerStats: BowlerInningsStats? = null,
    val target: Int = 0,
    val ballsRemaining: Int = 0,
    val runsNeeded: Int = 0,
    val requiredRunRate: Double = 0.0,
    val equationText: String = ""
)
