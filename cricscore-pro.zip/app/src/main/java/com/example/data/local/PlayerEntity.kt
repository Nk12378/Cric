package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "players",
    indices = [
        Index(value = ["matchId", "teamName"])
    ]
)
data class PlayerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val matchId: String,
    val teamName: String,
    val playerName: String,
    val role: String = "ALL_ROUNDER",
    val battingOrder: Int = 0,
    val isCaptain: Boolean = false,
    val isWicketKeeper: Boolean = false
)
