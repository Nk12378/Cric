package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TournamentEntity::class,
        MatchEntity::class,
        BallEntity::class,
        PlayerEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CricScoreDatabase : RoomDatabase() {

    abstract fun cricScoreDao(): CricScoreDao

    companion object {
        @Volatile
        private var INSTANCE: CricScoreDatabase? = null

        fun getInstance(context: Context): CricScoreDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CricScoreDatabase::class.java,
                    "cric_score_pro.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
