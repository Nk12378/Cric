package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CricScoreDao {

    // Tournament queries
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournament(tournament: TournamentEntity)

    @Query("SELECT * FROM tournaments ORDER BY createdAt DESC")
    fun getAllTournamentsFlow(): Flow<List<TournamentEntity>>

    @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
    suspend fun getTournamentById(id: String): TournamentEntity?

    // Match queries
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchEntity)

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Query("SELECT * FROM matches ORDER BY updatedAt DESC")
    fun getAllMatchesFlow(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE status LIKE 'LIVE%' OR status = 'INNINGS_BREAK' ORDER BY updatedAt DESC")
    fun getLiveMatchesFlow(): Flow<List<MatchEntity>>

    @Query("SELECT * FROM matches WHERE id = :matchId LIMIT 1")
    suspend fun getMatchById(matchId: String): MatchEntity?

    @Query("SELECT * FROM matches WHERE id = :matchId LIMIT 1")
    fun getMatchFlow(matchId: String): Flow<MatchEntity?>

    @Query("SELECT * FROM matches WHERE matchCode = :code LIMIT 1")
    suspend fun getMatchByCode(code: String): MatchEntity?

    // Ball queries
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBall(ball: BallEntity): Long

    @Query("SELECT * FROM balls WHERE matchId = :matchId AND innings = :innings ORDER BY id ASC")
    fun getBallsFlowForInnings(matchId: String, innings: Int): Flow<List<BallEntity>>

    @Query("SELECT * FROM balls WHERE matchId = :matchId AND innings = :innings ORDER BY id ASC")
    suspend fun getBallsForInnings(matchId: String, innings: Int): List<BallEntity>

    @Query("SELECT * FROM balls WHERE matchId = :matchId ORDER BY id ASC")
    fun getAllBallsFlow(matchId: String): Flow<List<BallEntity>>

    @Query("SELECT * FROM balls WHERE matchId = :matchId ORDER BY id ASC")
    suspend fun getAllBalls(matchId: String): List<BallEntity>

    @Query("SELECT * FROM balls WHERE matchId = :matchId AND innings = :innings ORDER BY id DESC LIMIT 1")
    suspend fun getLastBallForInnings(matchId: String, innings: Int): BallEntity?

    @Query("DELETE FROM balls WHERE id = :ballId")
    suspend fun deleteBallById(ballId: Long)

    @Query("DELETE FROM balls WHERE matchId = :matchId")
    suspend fun deleteBallsForMatch(matchId: String)

    // Player queries
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayers(players: List<PlayerEntity>)

    @Query("SELECT * FROM players WHERE matchId = :matchId ORDER BY battingOrder ASC")
    fun getPlayersForMatchFlow(matchId: String): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM players WHERE matchId = :matchId ORDER BY battingOrder ASC")
    suspend fun getPlayersForMatch(matchId: String): List<PlayerEntity>

    @Query("SELECT * FROM players WHERE matchId = :matchId AND teamName = :teamName ORDER BY battingOrder ASC")
    suspend fun getPlayersForTeam(matchId: String, teamName: String): List<PlayerEntity>
}
