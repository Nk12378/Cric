package com.example.data.repository

import com.example.data.local.BallEntity
import com.example.data.local.CricScoreDao
import com.example.data.local.MatchEntity
import com.example.data.local.PlayerEntity
import com.example.data.local.TournamentEntity
import com.example.data.model.CricketStatsCalculator
import com.example.data.model.FullMatchState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.util.Locale
import java.util.UUID

class CricketRepository(private val dao: CricScoreDao) {

    val allMatchesFlow: Flow<List<MatchEntity>> = dao.getAllMatchesFlow()
    val liveMatchesFlow: Flow<List<MatchEntity>> = dao.getLiveMatchesFlow()
    val allTournamentsFlow: Flow<List<TournamentEntity>> = dao.getAllTournamentsFlow()

    fun getFullMatchStateFlow(matchId: String): Flow<FullMatchState?> {
        return combine(
            dao.getMatchFlow(matchId),
            dao.getBallsFlowForInnings(matchId, 1),
            dao.getBallsFlowForInnings(matchId, 2)
        ) { match, inn1Balls, inn2Balls ->
            if (match == null) null
            else CricketStatsCalculator.buildFullMatchState(match, inn1Balls, inn2Balls)
        }
    }

    suspend fun getMatchById(matchId: String): MatchEntity? = dao.getMatchById(matchId)
    suspend fun getMatchByCode(code: String): MatchEntity? = dao.getMatchByCode(code.trim().uppercase())
    suspend fun getPlayersForMatch(matchId: String): List<PlayerEntity> = dao.getPlayersForMatch(matchId)

    suspend fun createTournament(name: String, season: String = "2026", venue: String = "Local Cricket Stadium"): String {
        val id = UUID.randomUUID().toString()
        val tournament = TournamentEntity(
            id = id,
            name = name,
            season = season,
            venue = venue
        )
        dao.insertTournament(tournament)
        return id
    }

    suspend fun createMatch(
        tournamentId: String,
        matchTitle: String,
        teamAName: String,
        teamBName: String,
        teamAShort: String,
        teamBShort: String,
        overs: Int = 20,
        maxOversPerBowler: Int = 4,
        teamAPlayers: List<String> = emptyList(),
        teamBPlayers: List<String> = emptyList()
    ): String {
        val matchId = UUID.randomUUID().toString()
        val matchCode = "CRIC-${(1000..9999).random()}"

        val match = MatchEntity(
            id = matchId,
            tournamentId = tournamentId,
            matchTitle = matchTitle,
            teamAName = teamAName,
            teamBName = teamBName,
            teamAShort = teamAShort,
            teamBShort = teamBShort,
            overs = overs,
            maxOversPerBowler = maxOversPerBowler,
            status = "UPCOMING",
            matchCode = matchCode
        )
        dao.insertMatch(match)

        val playersToInsert = mutableListOf<PlayerEntity>()
        teamAPlayers.forEachIndexed { index, name ->
            playersToInsert.add(
                PlayerEntity(
                    matchId = matchId,
                    teamName = teamAName,
                    playerName = name,
                    battingOrder = index + 1
                )
            )
        }
        teamBPlayers.forEachIndexed { index, name ->
            playersToInsert.add(
                PlayerEntity(
                    matchId = matchId,
                    teamName = teamBName,
                    playerName = name,
                    battingOrder = index + 1
                )
            )
        }
        if (playersToInsert.isNotEmpty()) {
            dao.insertPlayers(playersToInsert)
        }

        return matchId
    }

    suspend fun startMatch(
        matchId: String,
        tossWinner: String,
        tossDecision: String,
        striker: String,
        nonStriker: String,
        openingBowler: String
    ) {
        val match = dao.getMatchById(matchId) ?: return

        val battingFirst = if (tossDecision == "BAT") {
            tossWinner
        } else {
            if (tossWinner == match.teamAName) match.teamBName else match.teamAName
        }

        val bowlingFirst = if (battingFirst == match.teamAName) match.teamBName else match.teamAName

        val updated = match.copy(
            tossWinnerTeam = tossWinner,
            tossDecision = tossDecision,
            battingFirstTeam = battingFirst,
            bowlingFirstTeam = bowlingFirst,
            status = "LIVE_INNINGS_1",
            currentInnings = 1,
            strikerName = striker,
            nonStrikerName = nonStriker,
            currentBowlerName = openingBowler,
            previousBowlerName = "",
            updatedAt = System.currentTimeMillis()
        )
        dao.updateMatch(updated)
    }

    suspend fun startSecondInnings(
        matchId: String,
        striker: String,
        nonStriker: String,
        openingBowler: String
    ) {
        val match = dao.getMatchById(matchId) ?: return
        val inn1Balls = dao.getBallsForInnings(matchId, 1)
        val inn1Summary = CricketStatsCalculator.calculateInningsSummary(
            1, match.battingFirstTeam, match.bowlingFirstTeam, inn1Balls, "", "", ""
        )
        val target = inn1Summary.totalRuns + 1

        val updated = match.copy(
            status = "LIVE_INNINGS_2",
            currentInnings = 2,
            target = target,
            strikerName = striker,
            nonStrikerName = nonStriker,
            currentBowlerName = openingBowler,
            previousBowlerName = "",
            updatedAt = System.currentTimeMillis()
        )
        dao.updateMatch(updated)
    }

    suspend fun setBowler(matchId: String, bowlerName: String) {
        val match = dao.getMatchById(matchId) ?: return
        dao.updateMatch(match.copy(currentBowlerName = bowlerName, updatedAt = System.currentTimeMillis()))
    }

    suspend fun swapStrike(matchId: String) {
        val match = dao.getMatchById(matchId) ?: return
        val newStriker = match.nonStrikerName
        val newNonStriker = match.strikerName
        dao.updateMatch(
            match.copy(
                strikerName = newStriker,
                nonStrikerName = newNonStriker,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun recordBall(
        matchId: String,
        runsScored: Int,
        extraType: String,
        extraRuns: Int,
        isWicket: Boolean,
        wicketType: String,
        fielderName: String = "",
        shotZone: String = "STRAIGHT",
        newBatsmanName: String = "",
        customCommentary: String = ""
    ) {
        val match = dao.getMatchById(matchId) ?: return
        val innings = match.currentInnings
        val currentBalls = dao.getBallsForInnings(matchId, innings)

        val legalBallsSoFar = currentBalls.count { it.isLegalBall }
        val isLegal = extraType != "WIDE" && extraType != "NO_BALL"

        val overNumber = legalBallsSoFar / 6
        val ballInOver = if (isLegal) (legalBallsSoFar % 6) + 1 else (legalBallsSoFar % 6)

        // Generate lively professional cricket commentary
        val commentary = if (customCommentary.isNotBlank()) customCommentary else generateCommentary(
            bowler = match.currentBowlerName,
            batter = match.strikerName,
            runs = runsScored,
            extraType = extraType,
            extraRuns = extraRuns,
            isWicket = isWicket,
            wicketType = wicketType,
            shotZone = shotZone,
            fielder = fielderName
        )

        val ball = BallEntity(
            matchId = matchId,
            innings = innings,
            overNumber = overNumber,
            ballInOver = ballInOver,
            isLegalBall = isLegal,
            batsmanName = match.strikerName,
            bowlerName = match.currentBowlerName,
            nonStrikerName = match.nonStrikerName,
            runsScored = runsScored,
            extraType = extraType,
            extraRuns = extraRuns,
            isWicket = isWicket,
            wicketType = wicketType,
            dismissedPlayerName = if (isWicket) match.strikerName else "",
            fielderName = fielderName,
            shotZone = shotZone,
            commentary = commentary,
            timestamp = System.currentTimeMillis()
        )
        dao.insertBall(ball)

        // Evaluate updated innings after this ball
        val updatedBalls = currentBalls + ball
        val newLegalCount = updatedBalls.count { it.isLegalBall }
        val newWicketsCount = updatedBalls.count { it.isWicket }
        val newTotalRuns = updatedBalls.sumOf { it.runsScored + it.extraRuns }

        var nextStriker = match.strikerName
        var nextNonStriker = match.nonStrikerName
        var nextBowler = match.currentBowlerName
        var prevBowler = match.previousBowlerName

        // Handle wicket replacement
        if (isWicket) {
            nextStriker = if (newBatsmanName.isNotBlank()) newBatsmanName else "Batter ${newWicketsCount + 2}"
        }

        // Strike rotation on odd runs (1, 3, 5 runs off bat, or odd running extras like 1 bye)
        val runsToRotate = runsScored + if (extraType == "BYE" || extraType == "LEG_BYE") extraRuns else 0
        if (runsToRotate % 2 != 0) {
            val temp = nextStriker
            nextStriker = nextNonStriker
            nextNonStriker = temp
        }

        var newStatus = match.status
        var newWinner = match.winner
        var newWinDesc = match.winDescription

        // Check Over completion
        val overJustEnded = isLegal && (newLegalCount % 6 == 0)
        if (overJustEnded) {
            // Batsmen switch ends at end of over
            val temp = nextStriker
            nextStriker = nextNonStriker
            nextNonStriker = temp

            prevBowler = nextBowler
            nextBowler = "" // Prompt scorer to select next bowler
        }

        // Check Innings 1 conclusion (All out at 10 wickets or overs complete)
        if (innings == 1) {
            val oversCompleted = newLegalCount >= match.overs * 6
            val allOut = newWicketsCount >= 10
            if (oversCompleted || allOut) {
                newStatus = "INNINGS_BREAK"
                val target = newTotalRuns + 1
                dao.updateMatch(
                    match.copy(
                        status = newStatus,
                        target = target,
                        strikerName = "",
                        nonStrikerName = "",
                        currentBowlerName = "",
                        previousBowlerName = "",
                        updatedAt = System.currentTimeMillis()
                    )
                )
                return
            }
        } else if (innings == 2) {
            // Innings 2 checks: Chase achieved or overs/wickets exhausted
            val battingTeam = if (match.bowlingFirstTeam.isNotBlank()) match.bowlingFirstTeam else match.teamBName
            val bowlingTeam = if (match.battingFirstTeam.isNotBlank()) match.battingFirstTeam else match.teamAName
            val target = match.target

            if (newTotalRuns >= target) {
                // Batting team won
                val wicketsRemaining = 10 - newWicketsCount
                val ballsLeft = (match.overs * 6) - newLegalCount
                newStatus = "COMPLETED"
                newWinner = battingTeam
                newWinDesc = "$battingTeam won by $wicketsRemaining wickets ($ballsLeft balls left)"
            } else {
                val oversCompleted = newLegalCount >= match.overs * 6
                val allOut = newWicketsCount >= 10
                if (oversCompleted || allOut) {
                    newStatus = "COMPLETED"
                    val margin = (target - 1) - newTotalRuns
                    if (margin == 0) {
                        newWinner = "Match Tied"
                        newWinDesc = "Match tied! Scores are level."
                    } else {
                        newWinner = bowlingTeam
                        newWinDesc = "$bowlingTeam won by $margin runs"
                    }
                }
            }
        }

        dao.updateMatch(
            match.copy(
                strikerName = nextStriker,
                nonStrikerName = nextNonStriker,
                currentBowlerName = nextBowler,
                previousBowlerName = prevBowler,
                status = newStatus,
                winner = newWinner,
                winDescription = newWinDesc,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun undoLastBall(matchId: String) {
        val match = dao.getMatchById(matchId) ?: return
        val lastBall = dao.getLastBallForInnings(matchId, match.currentInnings) ?: return

        dao.deleteBallById(lastBall.id)

        // Restore striker, non-striker, bowler from previous state
        val remainingBalls = dao.getBallsForInnings(matchId, match.currentInnings)
        val prevLast = remainingBalls.lastOrNull()

        var restoredStriker = lastBall.batsmanName
        var restoredNonStriker = lastBall.nonStrikerName
        var restoredBowler = lastBall.bowlerName

        if (prevLast != null) {
            restoredBowler = prevLast.bowlerName
        }

        val restoredStatus = if (match.currentInnings == 1) "LIVE_INNINGS_1" else "LIVE_INNINGS_2"

        dao.updateMatch(
            match.copy(
                strikerName = restoredStriker,
                nonStrikerName = restoredNonStriker,
                currentBowlerName = restoredBowler,
                status = restoredStatus,
                winner = "",
                winDescription = "",
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    private fun generateCommentary(
        bowler: String,
        batter: String,
        runs: Int,
        extraType: String,
        extraRuns: Int,
        isWicket: Boolean,
        wicketType: String,
        shotZone: String,
        fielder: String
    ): String {
        val zoneName = shotZone.replace("_", " ").lowercase(Locale.ROOT)
        return when {
            isWicket -> when (wicketType) {
                "BOWLED" -> "OUT! Clean bowled! $bowler beats $batter all ends up with sheer pace, dismantling the stumps!"
                "CAUGHT" -> if (fielder.isNotBlank()) "OUT! Caught by $fielder! $batter looks to go over $zoneName but mistimes it straight to hand!" else "OUT! Caught and bowled! Magnificent reflex catch by $bowler!"
                "LBW" -> "OUT! Loud appeal for LBW and the umpire raises the finger! Trapped right in front by $bowler!"
                "RUN_OUT" -> "OUT! Direct hit! Brilliant fielding, $batter is run out by miles!"
                "STUMPED" -> "OUT! Stumped! $batter steps down, misses the turn, and the keeper does the rest in a flash!"
                else -> "OUT! Wicket falls! $batter has to depart!"
            }
            extraType == "WIDE" -> "$bowler sprays it way down the leg side, signaled WIDE by the umpire."
            extraType == "NO_BALL" -> "NO BALL! $bowler oversteps the crease! Free Hit coming up for the batting side."
            runs == 6 -> "SIX! What a magnificent blow! $batter connects cleanly and launches it high over $zoneName into the stands!"
            runs == 4 -> "FOUR! Pure timing! $batter leans into the stroke and drives exquisitely through $zoneName to the fence!"
            runs == 3 -> "Three runs taken! Sliced through $zoneName, great running between the wickets."
            runs == 2 -> "Driven into the gap at $zoneName, batsmen hustle back quickly for a comfortable two."
            runs == 1 -> "Tucked away off the hips towards $zoneName for a single to rotate the strike."
            else -> "Good length delivery on off stump, $batter defends solidly into the pitch. No run."
        }
    }

    suspend fun seedInitialDataIfEmpty() {
        val existingTournaments = dao.getTournamentById("tourn-ipl-local")
        if (existingTournaments != null) return

        // Create premier local tournament
        val tournamentId = "tourn-ipl-local"
        dao.insertTournament(
            TournamentEntity(
                id = tournamentId,
                name = "City Premier League T20",
                season = "Season 8 (2026)",
                venue = "Wankhede Sports Complex",
                bannerUrl = ""
            )
        )

        // Seed Match 1: LIVE 2nd innings thriller!
        val match1Id = "match-live-01"
        val match1 = MatchEntity(
            id = match1Id,
            tournamentId = tournamentId,
            matchTitle = "Qualifier 1 - Mumbai Strikers vs Delhi Titans",
            teamAName = "Mumbai Strikers",
            teamBName = "Delhi Titans",
            teamAShort = "MS",
            teamBShort = "DT",
            overs = 20,
            maxOversPerBowler = 4,
            tossWinnerTeam = "Delhi Titans",
            tossDecision = "BOWL",
            battingFirstTeam = "Mumbai Strikers",
            bowlingFirstTeam = "Delhi Titans",
            status = "LIVE_INNINGS_2",
            currentInnings = 2,
            strikerName = "Rishabh Pant",
            nonStrikerName = "Axar Patel",
            currentBowlerName = "Jasprit Bumrah",
            previousBowlerName = "Hardik Pandya",
            target = 168,
            matchCode = "CRIC-7421"
        )
        dao.insertMatch(match1)

        // Players for Match 1
        val mumbaiPlayers = listOf(
            "Rohit Sharma", "Ishan Kishan", "Suryakumar Yadav", "Tilak Varma",
            "Hardik Pandya", "Tim David", "Jasprit Bumrah", "Piyush Chawla",
            "Akash Madhwal", "Gerald Coetzee", "Nuwan Thushara"
        ).mapIndexed { i, p ->
            PlayerEntity(matchId = match1Id, teamName = "Mumbai Strikers", playerName = p, battingOrder = i + 1)
        }
        val delhiPlayers = listOf(
            "David Warner", "Prithvi Shaw", "Mitchell Marsh", "Rishabh Pant",
            "Tristan Stubbs", "Axar Patel", "Kuldeep Yadav", "Anrich Nortje",
            "Khaleel Ahmed", "Mukesh Kumar", "Ishant Sharma"
        ).mapIndexed { i, p ->
            PlayerEntity(matchId = match1Id, teamName = "Delhi Titans", playerName = p, battingOrder = i + 1)
        }
        dao.insertPlayers(mumbaiPlayers + delhiPlayers)

        // Populate Innings 1 balls (Mumbai Strikers scored 167/6 in 20 overs)
        seedInnings1Balls(match1Id)

        // Populate Innings 2 balls (Delhi Titans are 118/3 in 13.4 overs, thrilling live chase!)
        seedInnings2Balls(match1Id)

        // Seed Match 2: COMPLETED match (Royal Challengers vs Super Kings)
        val match2Id = "match-comp-02"
        val match2 = MatchEntity(
            id = match2Id,
            tournamentId = tournamentId,
            matchTitle = "League Match 14 - Royal Challengers vs Super Kings",
            teamAName = "Royal Challengers",
            teamBName = "Super Kings",
            teamAShort = "RCB",
            teamBShort = "CSK",
            overs = 20,
            maxOversPerBowler = 4,
            tossWinnerTeam = "Royal Challengers",
            tossDecision = "BAT",
            battingFirstTeam = "Royal Challengers",
            bowlingFirstTeam = "Super Kings",
            status = "COMPLETED",
            currentInnings = 2,
            target = 186,
            winner = "Royal Challengers",
            winDescription = "Royal Challengers won by 14 runs",
            matchCode = "CRIC-3912"
        )
        dao.insertMatch(match2)
    }

    private suspend fun seedInnings1Balls(matchId: String) {
        // Mumbai 167/6 in 20 overs
        val sampleEvents = listOf(
            // Over 1 (0-1) by Khaleel Ahmed to Rohit & Ishan
            BallEntity(matchId = matchId, innings = 1, overNumber = 0, ballInOver = 1, isLegalBall = true, batsmanName = "Rohit Sharma", bowlerName = "Khaleel Ahmed", nonStrikerName = "Ishan Kishan", runsScored = 4, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "COVER", commentary = "FOUR! Rohit caresses it through extra cover!"),
            BallEntity(matchId = matchId, innings = 1, overNumber = 0, ballInOver = 2, isLegalBall = true, batsmanName = "Rohit Sharma", bowlerName = "Khaleel Ahmed", nonStrikerName = "Ishan Kishan", runsScored = 1, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "POINT", commentary = "Single pushed to backward point."),
            BallEntity(matchId = matchId, innings = 1, overNumber = 0, ballInOver = 3, isLegalBall = true, batsmanName = "Ishan Kishan", bowlerName = "Khaleel Ahmed", nonStrikerName = "Rohit Sharma", runsScored = 0, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "STRAIGHT", commentary = "Defended back to the bowler."),
            BallEntity(matchId = matchId, innings = 1, overNumber = 0, ballInOver = 4, isLegalBall = true, batsmanName = "Ishan Kishan", bowlerName = "Khaleel Ahmed", nonStrikerName = "Rohit Sharma", runsScored = 6, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "MID_WICKET", commentary = "SIX! Ishan pulls with authority over deep mid-wicket!"),
            BallEntity(matchId = matchId, innings = 1, overNumber = 0, ballInOver = 5, isLegalBall = true, batsmanName = "Ishan Kishan", bowlerName = "Khaleel Ahmed", nonStrikerName = "Rohit Sharma", runsScored = 0, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "COVER", commentary = "Dot ball to cover."),
            BallEntity(matchId = matchId, innings = 1, overNumber = 0, ballInOver = 6, isLegalBall = true, batsmanName = "Ishan Kishan", bowlerName = "Khaleel Ahmed", nonStrikerName = "Rohit Sharma", runsScored = 1, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "FINE_LEG", commentary = "Flicked to fine leg for one."),

            // Over 2 by Ishant Sharma
            BallEntity(matchId = matchId, innings = 1, overNumber = 1, ballInOver = 1, isLegalBall = true, batsmanName = "Ishan Kishan", bowlerName = "Ishant Sharma", nonStrikerName = "Rohit Sharma", runsScored = 0, extraType = "NONE", extraRuns = 0, isWicket = true, wicketType = "BOWLED", dismissedPlayerName = "Ishan Kishan", shotZone = "STRAIGHT", commentary = "WICKET! Clean bowled! Ishant gets the off stump rattling!"),
            BallEntity(matchId = matchId, innings = 1, overNumber = 1, ballInOver = 2, isLegalBall = true, batsmanName = "Suryakumar Yadav", bowlerName = "Ishant Sharma", nonStrikerName = "Rohit Sharma", runsScored = 4, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "FINE_LEG", commentary = "FOUR! Typical Surya flick over fine leg for boundary!"),
            BallEntity(matchId = matchId, innings = 1, overNumber = 1, ballInOver = 3, isLegalBall = false, batsmanName = "Suryakumar Yadav", bowlerName = "Ishant Sharma", nonStrikerName = "Rohit Sharma", runsScored = 0, extraType = "WIDE", extraRuns = 1, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "STRAIGHT", commentary = "Wide down the leg side."),
            BallEntity(matchId = matchId, innings = 1, overNumber = 1, ballInOver = 3, isLegalBall = true, batsmanName = "Suryakumar Yadav", bowlerName = "Ishant Sharma", nonStrikerName = "Rohit Sharma", runsScored = 1, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "THIRD_MAN", commentary = "Steered down to third man for one."),
            BallEntity(matchId = matchId, innings = 1, overNumber = 1, ballInOver = 4, isLegalBall = true, batsmanName = "Rohit Sharma", bowlerName = "Ishant Sharma", nonStrikerName = "Suryakumar Yadav", runsScored = 6, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "LONG_ON", commentary = "SIX! Rohit steps out and lofted over long on!"),
            BallEntity(matchId = matchId, innings = 1, overNumber = 1, ballInOver = 5, isLegalBall = true, batsmanName = "Rohit Sharma", bowlerName = "Ishant Sharma", nonStrikerName = "Suryakumar Yadav", runsScored = 2, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "MID_WICKET", commentary = "Coupled in the deep."),
            BallEntity(matchId = matchId, innings = 1, overNumber = 1, ballInOver = 6, isLegalBall = true, batsmanName = "Rohit Sharma", bowlerName = "Ishant Sharma", nonStrikerName = "Suryakumar Yadav", runsScored = 1, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "SQUARE_LEG", commentary = "Single to end over 2.")
        )
        sampleEvents.forEach { dao.insertBall(it) }

        // Additional overs to reach 167 runs
        val bowlers = listOf("Mukesh Kumar", "Axar Patel", "Kuldeep Yadav", "Anrich Nortje")
        val batters = listOf("Rohit Sharma", "Suryakumar Yadav", "Tilak Varma", "Hardik Pandya", "Tim David")
        var currentScore = 31
        var wickets = 1

        for (ov in 2..19) {
            val bw = bowlers[ov % bowlers.size]
            for (b in 1..6) {
                val runs = when ((1..10).random()) {
                    1, 2 -> 0
                    3, 4, 5 -> 1
                    6, 7 -> 2
                    8, 9 -> 4
                    else -> 6
                }
                val isW = wickets < 6 && (ov == 6 || ov == 11 || ov == 15 || ov == 18) && b == 3
                val dismissed = if (isW) { wickets++; batters.getOrElse(wickets) { "Batter" } } else ""
                val zones = listOf("COVER", "MID_WICKET", "LONG_ON", "POINT", "FINE_LEG", "STRAIGHT")
                val zone = zones.random()

                dao.insertBall(
                    BallEntity(
                        matchId = matchId,
                        innings = 1,
                        overNumber = ov,
                        ballInOver = b,
                        isLegalBall = true,
                        batsmanName = batters[(ov / 4) % batters.size],
                        bowlerName = bw,
                        nonStrikerName = batters[((ov / 4) + 1) % batters.size],
                        runsScored = if (isW) 0 else runs,
                        extraType = "NONE",
                        extraRuns = 0,
                        isWicket = isW,
                        wicketType = if (isW) (if (ov % 2 == 0) "BOWLED" else "CAUGHT") else "NONE",
                        dismissedPlayerName = dismissed,
                        fielderName = if (isW) "Warner" else "",
                        shotZone = zone,
                        commentary = if (isW) "OUT! Wicket falls in over $ov!" else "Scored $runs through $zone."
                    )
                )
            }
        }
    }

    private suspend fun seedInnings2Balls(matchId: String) {
        // Delhi Titans chasing 168, currently 118/3 in 13.4 overs
        val bowlers = listOf("Jasprit Bumrah", "Gerald Coetzee", "Hardik Pandya", "Piyush Chawla")
        val batters = listOf("David Warner", "Prithvi Shaw", "Mitchell Marsh", "Rishabh Pant", "Axar Patel")
        var wickets = 0

        for (ov in 0..12) {
            val bw = bowlers[ov % bowlers.size]
            for (b in 1..6) {
                val isW = wickets < 3 && (ov == 3 || ov == 7 || ov == 10) && b == 4
                val runs = if (isW) 0 else when ((1..8).random()) {
                    1, 2 -> 0
                    3, 4 -> 1
                    5 -> 2
                    6, 7 -> 4
                    else -> 6
                }
                if (isW) wickets++
                val zones = listOf("COVER", "MID_WICKET", "LONG_ON", "SQUARE_LEG", "THIRD_MAN", "STRAIGHT")

                dao.insertBall(
                    BallEntity(
                        matchId = matchId,
                        innings = 2,
                        overNumber = ov,
                        ballInOver = b,
                        isLegalBall = true,
                        batsmanName = if (ov >= 10) "Rishabh Pant" else batters[ov % 3],
                        bowlerName = bw,
                        nonStrikerName = if (ov >= 10) "Axar Patel" else batters[(ov + 1) % 3],
                        runsScored = runs,
                        extraType = "NONE",
                        extraRuns = 0,
                        isWicket = isW,
                        wicketType = if (isW) "CAUGHT" else "NONE",
                        dismissedPlayerName = if (isW) batters[wickets - 1] else "",
                        fielderName = if (isW) "Suryakumar" else "",
                        shotZone = zones.random(),
                        commentary = if (isW) "OUT! Caught in the deep!" else "Punched away for $runs runs."
                    )
                )
            }
        }

        // Ongoing 14th over (over index 13) by Bumrah
        val ongoingOver = listOf(
            BallEntity(matchId = matchId, innings = 2, overNumber = 13, ballInOver = 1, isLegalBall = true, batsmanName = "Rishabh Pant", bowlerName = "Jasprit Bumrah", nonStrikerName = "Axar Patel", runsScored = 1, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "POINT", commentary = "Pushed softly to point for a sharp single."),
            BallEntity(matchId = matchId, innings = 2, overNumber = 13, ballInOver = 2, isLegalBall = true, batsmanName = "Axar Patel", bowlerName = "Jasprit Bumrah", nonStrikerName = "Rishabh Pant", runsScored = 0, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "STRAIGHT", commentary = "145 km/h yorker dug out right on the crease!"),
            BallEntity(matchId = matchId, innings = 2, overNumber = 13, ballInOver = 3, isLegalBall = true, batsmanName = "Axar Patel", bowlerName = "Jasprit Bumrah", nonStrikerName = "Rishabh Pant", runsScored = 4, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "THIRD_MAN", commentary = "FOUR! Edged but flies past slip down to the third man fence!"),
            BallEntity(matchId = matchId, innings = 2, overNumber = 13, ballInOver = 4, isLegalBall = true, batsmanName = "Axar Patel", bowlerName = "Jasprit Bumrah", nonStrikerName = "Rishabh Pant", runsScored = 1, extraType = "NONE", extraRuns = 0, isWicket = false, wicketType = "NONE", dismissedPlayerName = "", shotZone = "FINE_LEG", commentary = "Tucked behind square for one.")
        )
        ongoingOver.forEach { dao.insertBall(it) }
    }
}
