package com.example.data.model

import com.example.data.local.BallEntity
import com.example.data.local.MatchEntity
import java.util.Locale

object CricketStatsCalculator {

    fun calculateInningsSummary(
        innings: Int,
        battingTeam: String,
        bowlingTeam: String,
        balls: List<BallEntity>,
        strikerName: String,
        nonStrikerName: String,
        currentBowlerName: String
    ): InningsScoreSummary {
        var totalRuns = 0
        var totalWickets = 0
        var totalLegalBalls = 0

        var wides = 0
        var noBalls = 0
        var byes = 0
        var legByes = 0
        var penalty = 0

        // Maps to accumulate batter and bowler data in appearance order
        val batterMap = LinkedHashMap<String, MutableBatterStats>()
        val bowlerMap = LinkedHashMap<String, MutableBowlerStats>()
        val fowList = mutableListOf<FallOfWicket>()

        var currentPartnershipRuns = 0
        var currentPartnershipBalls = 0

        // Track over-by-over
        val overRunsMap = mutableMapOf<Int, Int>()
        // Track bowler runs in each over to compute maidens
        val bowlerOverData = mutableMapOf<Pair<String, Int>, OverRecord>()

        for (ball in balls) {
            val runsOffBat = ball.runsScored
            val extraRuns = ball.extraRuns
            val ballTotal = runsOffBat + extraRuns
            totalRuns += ballTotal

            if (ball.isLegalBall) {
                totalLegalBalls++
            }

            // Extras tally
            when (ball.extraType) {
                "WIDE" -> wides += extraRuns
                "NO_BALL" -> noBalls += extraRuns
                "BYE" -> byes += extraRuns
                "LEG_BYE" -> legByes += extraRuns
                "PENALTY" -> penalty += extraRuns
            }

            // Over runs tracking
            overRunsMap[ball.overNumber] = (overRunsMap[ball.overNumber] ?: 0) + ballTotal

            // Batter stats: Wides are NOT counted as balls faced by batter
            if (ball.batsmanName.isNotBlank()) {
                val bStats = batterMap.getOrPut(ball.batsmanName) { MutableBatterStats(ball.batsmanName) }
                bStats.runs += runsOffBat
                if (ball.extraType != "WIDE") {
                    bStats.balls += 1
                }
                if (runsOffBat == 4) bStats.fours += 1
                if (runsOffBat == 6) bStats.sixes += 1
            }

            // Non-striker entry ensures they appear on the scorecard
            if (ball.nonStrikerName.isNotBlank()) {
                batterMap.getOrPut(ball.nonStrikerName) { MutableBatterStats(ball.nonStrikerName) }
            }

            // Bowler stats
            if (ball.bowlerName.isNotBlank()) {
                val bwStats = bowlerMap.getOrPut(ball.bowlerName) { MutableBowlerStats(ball.bowlerName) }
                if (ball.isLegalBall) {
                    bwStats.legalBalls += 1
                    if (runsOffBat == 0 && extraRuns == 0) {
                        bwStats.dots += 1
                    }
                }
                // Bowler is charged for runs off bat, wides, and no-balls (byes and leg byes are NOT charged to bowler)
                val bowlerCharge = runsOffBat + if (ball.extraType == "WIDE" || ball.extraType == "NO_BALL") extraRuns else 0
                bwStats.runsConceded += bowlerCharge

                // Track for maidens
                val key = Pair(ball.bowlerName, ball.overNumber)
                val overRec = bowlerOverData.getOrPut(key) { OverRecord() }
                if (ball.isLegalBall) overRec.legalBalls++
                overRec.runsConceded += bowlerCharge

                if (ball.isWicket && isBowlerWicket(ball.wicketType)) {
                    bwStats.wickets += 1
                }
            }

            // Partnership tracking
            currentPartnershipRuns += ballTotal
            if (ball.isLegalBall) {
                currentPartnershipBalls++
            }

            // Wicket handling
            if (ball.isWicket) {
                totalWickets++
                val dismissedName = if (ball.dismissedPlayerName.isNotBlank()) ball.dismissedPlayerName else ball.batsmanName
                val dismissedBatter = batterMap.getOrPut(dismissedName) { MutableBatterStats(dismissedName) }
                dismissedBatter.isOut = true
                dismissedBatter.dismissal = formatDismissal(ball)

                val overFormatted = "${totalLegalBalls / 6}.${totalLegalBalls % 6}"
                fowList.add(
                    FallOfWicket(
                        wicketNumber = totalWickets,
                        teamScore = totalRuns,
                        overFormatted = overFormatted,
                        batsmanName = dismissedName
                    )
                )

                // Reset partnership
                currentPartnershipRuns = 0
                currentPartnershipBalls = 0
            }
        }

        // Calculate maidens: 6 legal balls in the over and 0 runs conceded by that bowler
        for ((key, overRec) in bowlerOverData) {
            if (overRec.legalBalls == 6 && overRec.runsConceded == 0) {
                bowlerMap[key.first]?.maidens = (bowlerMap[key.first]?.maidens ?: 0) + 1
            }
        }

        // Current over balls (balls with the highest overNumber, or last 6-10 balls)
        val maxOver = balls.maxOfOrNull { it.overNumber } ?: 0
        val currentOverBalls = balls.filter { it.overNumber == maxOver }

        // Build list of batter stats
        val batterList = batterMap.values.map { m ->
            val isBatting = !m.isOut && (m.name == strikerName || m.name == nonStrikerName)
            BatsmanInningsStats(
                name = m.name,
                runs = m.runs,
                balls = m.balls,
                fours = m.fours,
                sixes = m.sixes,
                dismissal = if (m.isOut) m.dismissal else if (isBatting) "batting" else "not out",
                isOut = m.isOut,
                isBatting = isBatting
            )
        }

        // Build list of bowler stats
        val bowlerList = bowlerMap.values.map { bw ->
            BowlerInningsStats(
                name = bw.name,
                legalBalls = bw.legalBalls,
                maidens = bw.maidens,
                runsConceded = bw.runsConceded,
                wickets = bw.wickets,
                dots = bw.dots
            )
        }

        // Over-by-over runs and cumulative runs
        val totalOvers = if (totalLegalBalls > 0) ((totalLegalBalls - 1) / 6) + 1 else 0
        val overRunsList = mutableListOf<Int>()
        val cumulativeRunsList = mutableListOf<Int>()
        var cum = 0
        for (o in 0 until totalOvers) {
            val r = overRunsMap[o] ?: 0
            overRunsList.add(r)
            cum += r
            cumulativeRunsList.add(cum)
        }

        return InningsScoreSummary(
            innings = innings,
            battingTeam = battingTeam,
            bowlingTeam = bowlingTeam,
            totalRuns = totalRuns,
            wickets = totalWickets,
            legalBalls = totalLegalBalls,
            extras = ExtrasSummary(wides, noBalls, byes, legByes, penalty),
            batters = batterList,
            bowlers = bowlerList,
            fallOfWickets = fowList,
            currentOverBalls = currentOverBalls,
            overRunsList = overRunsList,
            cumulativeRunsList = cumulativeRunsList,
            currentPartnershipRuns = currentPartnershipRuns,
            currentPartnershipBalls = currentPartnershipBalls
        )
    }

    private fun isBowlerWicket(wicketType: String): Boolean {
        return wicketType != "RUN_OUT" && wicketType != "RETIRED_HURT" && wicketType != "OBSTRUCTING_FIELD"
    }

    private fun formatDismissal(ball: BallEntity): String {
        return when (ball.wicketType) {
            "BOWLED" -> "b ${ball.bowlerName}"
            "CAUGHT" -> if (ball.fielderName.isNotBlank()) "c ${ball.fielderName} b ${ball.bowlerName}" else "c & b ${ball.bowlerName}"
            "LBW" -> "lbw b ${ball.bowlerName}"
            "STUMPED" -> if (ball.fielderName.isNotBlank()) "st ${ball.fielderName} b ${ball.bowlerName}" else "st b ${ball.bowlerName}"
            "HIT_WICKET" -> "hit wicket b ${ball.bowlerName}"
            "RUN_OUT" -> if (ball.fielderName.isNotBlank()) "run out (${ball.fielderName})" else "run out"
            "RETIRED_HURT" -> "retired hurt"
            else -> "out"
        }
    }

    fun buildFullMatchState(
        match: MatchEntity,
        innings1Balls: List<BallEntity>,
        innings2Balls: List<BallEntity>
    ): FullMatchState {
        val battingFirst = if (match.battingFirstTeam.isNotBlank()) match.battingFirstTeam else match.teamAName
        val bowlingFirst = if (match.bowlingFirstTeam.isNotBlank()) match.bowlingFirstTeam else match.teamBName

        val battingSecond = bowlingFirst
        val bowlingSecond = battingFirst

        val inn1 = calculateInningsSummary(
            innings = 1,
            battingTeam = battingFirst,
            bowlingTeam = bowlingFirst,
            balls = innings1Balls,
            strikerName = if (match.currentInnings == 1) match.strikerName else "",
            nonStrikerName = if (match.currentInnings == 1) match.nonStrikerName else "",
            currentBowlerName = if (match.currentInnings == 1) match.currentBowlerName else ""
        )

        val inn2 = if (match.currentInnings >= 2 || innings2Balls.isNotEmpty()) {
            calculateInningsSummary(
                innings = 2,
                battingTeam = battingSecond,
                bowlingTeam = bowlingSecond,
                balls = innings2Balls,
                strikerName = if (match.currentInnings == 2) match.strikerName else "",
                nonStrikerName = if (match.currentInnings == 2) match.nonStrikerName else "",
                currentBowlerName = if (match.currentInnings == 2) match.currentBowlerName else ""
            )
        } else null

        val currentInn = if (match.currentInnings == 1) inn1 else (inn2 ?: inn1)

        val strikerStats = currentInn.batters.find { it.name == match.strikerName }
        val nonStrikerStats = currentInn.batters.find { it.name == match.nonStrikerName }
        val currentBowlerStats = currentInn.bowlers.find { it.name == match.currentBowlerName }

        val target = if (match.target > 0) match.target else if (match.currentInnings >= 2) inn1.totalRuns + 1 else 0

        var runsNeeded = 0
        var ballsRemaining = 0
        var rrr = 0.0
        var equation = ""

        if (match.currentInnings == 2 && target > 0) {
            val totalMatchBalls = match.overs * 6
            runsNeeded = (target - (inn2?.totalRuns ?: 0)).coerceAtLeast(0)
            ballsRemaining = (totalMatchBalls - (inn2?.legalBalls ?: 0)).coerceAtLeast(0)

            if (ballsRemaining > 0 && runsNeeded > 0) {
                rrr = (runsNeeded.toDouble() / ballsRemaining) * 6.0
                equation = "$battingSecond need $runsNeeded runs in $ballsRemaining balls (RRR: ${String.format(Locale.US, "%.2f", rrr)})"
            } else if (runsNeeded <= 0) {
                equation = "$battingSecond won the match!"
            } else {
                equation = "Innings completed"
            }
        }

        val allRecent = if (match.currentInnings == 1) innings1Balls else innings2Balls
        val recentBalls = allRecent.takeLast(12)

        return FullMatchState(
            match = match,
            innings1Summary = inn1,
            innings2Summary = inn2,
            currentInningsSummary = currentInn,
            recentBalls = recentBalls,
            strikerStats = strikerStats,
            nonStrikerStats = nonStrikerStats,
            currentBowlerStats = currentBowlerStats,
            target = target,
            ballsRemaining = ballsRemaining,
            runsNeeded = runsNeeded,
            requiredRunRate = rrr,
            equationText = equation
        )
    }

    private class MutableBatterStats(
        val name: String,
        var runs: Int = 0,
        var balls: Int = 0,
        var fours: Int = 0,
        var sixes: Int = 0,
        var isOut: Boolean = false,
        var dismissal: String = "not out"
    )

    private class MutableBowlerStats(
        val name: String,
        var legalBalls: Int = 0,
        var maidens: Int = 0,
        var runsConceded: Int = 0,
        var wickets: Int = 0,
        var dots: Int = 0
    )

    private class OverRecord(
        var legalBalls: Int = 0,
        var runsConceded: Int = 0
    )
}
