package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BallEntity
import com.example.data.model.FullMatchState
import com.example.ui.theme.CricketGold
import com.example.ui.theme.ScoreDotGray
import com.example.ui.theme.ScoreExtraOrange
import com.example.ui.theme.ScoreFourBlue
import com.example.ui.theme.ScoreSixPurple
import com.example.ui.theme.ScoreWicketRed

@Composable
fun LiveCommentaryScreen(
    state: FullMatchState,
    modifier: Modifier = Modifier
) {
    var filterType by remember { mutableStateOf("ALL") } // ALL, WICKETS, BOUNDARIES

    val currentInningsBalls = state.currentInningsSummary.let { inn ->
        // We can inspect recentBalls or build from summary
        state.recentBalls
    }

    val reversedBalls = state.recentBalls.reversed().filter { ball ->
        when (filterType) {
            "WICKETS" -> ball.isWicket
            "BOUNDARIES" -> ball.runsScored == 4 || ball.runsScored == 6
            else -> true
        }
    }

    Column(modifier = modifier.padding(horizontal = 16.dp)) {
        // Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterType == "ALL",
                onClick = { filterType = "ALL" },
                label = { Text("All Balls") },
                modifier = Modifier.testTag("filter_all")
            )
            FilterChip(
                selected = filterType == "BOUNDARIES",
                onClick = { filterType = "BOUNDARIES" },
                label = { Text("4s & 6s") },
                modifier = Modifier.testTag("filter_boundaries")
            )
            FilterChip(
                selected = filterType == "WICKETS",
                onClick = { filterType = "WICKETS" },
                label = { Text("Wickets") },
                modifier = Modifier.testTag("filter_wickets")
            )
        }

        if (reversedBalls.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No balls match filter",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(reversedBalls, key = { it.id }) { ball ->
                    BallCommentaryItem(ball = ball)
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
private fun BallCommentaryItem(ball: BallEntity) {
    val overText = "${ball.overNumber}.${ball.ballInOver}"
    val (badgeText, badgeBg) = when {
        ball.isWicket -> "W" to ScoreWicketRed
        ball.runsScored == 6 -> "6" to ScoreSixPurple
        ball.runsScored == 4 -> "4" to ScoreFourBlue
        ball.extraType == "WIDE" -> "${ball.extraRuns}wd" to ScoreExtraOrange
        ball.extraType == "NO_BALL" -> "${ball.runsScored + ball.extraRuns}nb" to ScoreExtraOrange
        ball.extraType == "BYE" -> "${ball.extraRuns}b" to ScoreExtraOrange
        ball.extraType == "LEG_BYE" -> "${ball.extraRuns}lb" to ScoreExtraOrange
        ball.runsScored > 0 -> "${ball.runsScored}" to Color(0xFF2E7D32)
        else -> "•" to ScoreDotGray
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("commentary_item_${ball.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (ball.isWicket) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
            else if (ball.runsScored >= 4) CricketGold.copy(alpha = 0.12f)
            else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            // Over number
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(38.dp)
            ) {
                Text(
                    text = overText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                // Badge
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(badgeBg, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = badgeText,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Commentary & Players
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${ball.bowlerName} to ${ball.batsmanName}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${ball.shotZone.replace('_', ' ').lowercase()}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = ball.commentary.ifBlank {
                        if (ball.isWicket) "Wicket! ${ball.wicketType}." else "Scored ${ball.runsScored} runs."
                    },
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
