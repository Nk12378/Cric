package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FullMatchState
import com.example.ui.components.WagonWheelView
import com.example.ui.theme.CricketBluePrimary
import com.example.ui.theme.CricketGold
import com.example.ui.theme.ScoreFourBlue
import com.example.ui.theme.ScoreSixPurple
import kotlin.math.max

@Composable
fun MatchStatsScreen(
    state: FullMatchState,
    modifier: Modifier = Modifier
) {
    val inn1 = state.innings1Summary
    val inn2 = state.innings2Summary

    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Partnership Card
        item {
            PartnershipCard(state = state)
        }

        // Wagon Wheel
        item {
            WagonWheelView(balls = state.recentBalls)
        }

        // Manhattan Chart (Runs per Over)
        item {
            ManhattanChartCard(state = state)
        }

        // Worm Graph (Cumulative score comparison)
        if (inn1.cumulativeRunsList.isNotEmpty()) {
            item {
                WormChartCard(state = state)
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun PartnershipCard(state: FullMatchState) {
    val inn = state.currentInningsSummary
    val striker = state.strikerStats
    val nonStriker = state.nonStrikerStats

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("partnership_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Current Partnership",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Striker
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = striker?.name ?: "Striker",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "${striker?.runs ?: 0} (${striker?.balls ?: 0})",
                        color = CricketGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Partnership Center
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "${inn.currentPartnershipRuns}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${inn.currentPartnershipBalls} balls",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Non-striker
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = nonStriker?.name ?: "Non-Striker",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "${nonStriker?.runs ?: 0} (${nonStriker?.balls ?: 0})",
                        color = CricketGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun ManhattanChartCard(state: FullMatchState) {
    val currentOverRuns = state.currentInningsSummary.overRunsList

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("manhattan_chart_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Manhattan Chart (Runs per Over)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (currentOverRuns.isEmpty()) {
                Text(
                    text = "Awaiting overs...",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                val maxRuns = max(currentOverRuns.maxOrNull() ?: 1, 15)
                val primaryColor = MaterialTheme.colorScheme.primary
                val goldColor = CricketGold

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .testTag("manhattan_canvas")
                ) {
                    val count = currentOverRuns.size
                    val spacing = 8f
                    val availableWidth = size.width - (spacing * (count + 1))
                    val barWidth = (availableWidth / count).coerceAtLeast(12f)
                    val heightRatio = (size.height - 24f) / maxRuns

                    currentOverRuns.forEachIndexed { index, runs ->
                        val barHeight = (runs * heightRatio).coerceAtLeast(4f)
                        val left = spacing + index * (barWidth + spacing)
                        val top = size.height - barHeight - 20f

                        // Bar
                        drawRoundRect(
                            color = if (runs >= 10) goldColor else primaryColor,
                            topLeft = Offset(left, top),
                            size = Size(barWidth, barHeight),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                        )
                    }

                    // Baseline
                    drawLine(
                        color = Color.Gray.copy(alpha = 0.4f),
                        start = Offset(0f, size.height - 18f),
                        end = Offset(size.width, size.height - 18f),
                        strokeWidth = 2f
                    )
                }

                // Overs text labels
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Over 1", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "Over ${currentOverRuns.size}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun WormChartCard(state: FullMatchState) {
    val inn1Cum = state.innings1Summary.cumulativeRunsList
    val inn2Cum = state.innings2Summary?.cumulativeRunsList ?: emptyList()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("worm_chart_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Worm Chart (Cumulative Score)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Chart Legend
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp).background(CricketBluePrimary, CircleShape))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = state.match.teamAName, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (inn2Cum.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(10.dp).background(CricketGold, CircleShape))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = state.match.teamBName, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val maxScore = max(
                (inn1Cum.maxOrNull() ?: 1),
                (inn2Cum.maxOrNull() ?: 1)
            )
            val maxOvers = max(inn1Cum.size, max(inn2Cum.size, state.match.overs))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .testTag("worm_canvas")
            ) {
                val chartHeight = size.height - 20f
                val chartWidth = size.width

                fun getOffset(overIdx: Int, score: Int): Offset {
                    val x = if (maxOvers > 1) (overIdx.toFloat() / (maxOvers - 1)) * chartWidth else 0f
                    val y = chartHeight - (score.toFloat() / maxScore * chartHeight)
                    return Offset(x, y)
                }

                // Grid lines
                drawLine(Color.Gray.copy(alpha = 0.2f), Offset(0f, chartHeight), Offset(chartWidth, chartHeight), 1.5f)
                drawLine(Color.Gray.copy(alpha = 0.2f), Offset(0f, chartHeight / 2), Offset(chartWidth, chartHeight / 2), 1f)

                // Innings 1 Curve
                if (inn1Cum.isNotEmpty()) {
                    val path1 = Path()
                    path1.moveTo(0f, chartHeight)
                    inn1Cum.forEachIndexed { i, score ->
                        val pt = getOffset(i, score)
                        path1.lineTo(pt.x, pt.y)
                    }
                    drawPath(
                        path = path1,
                        color = CricketBluePrimary,
                        style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                    )
                }

                // Innings 2 Curve
                if (inn2Cum.isNotEmpty()) {
                    val path2 = Path()
                    path2.moveTo(0f, chartHeight)
                    inn2Cum.forEachIndexed { i, score ->
                        val pt = getOffset(i, score)
                        path2.lineTo(pt.x, pt.y)
                    }
                    drawPath(
                        path = path2,
                        color = CricketGold,
                        style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                    )
                }
            }
        }
    }
}
