package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MatchEntity
import com.example.data.local.TournamentEntity
import com.example.ui.theme.CricketBlueDark
import com.example.ui.theme.CricketBluePrimary
import com.example.ui.theme.CricketGold
import com.example.ui.theme.ScoreWicketRed
import com.example.viewmodel.CricketViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: CricketViewModel,
    onNavigateToScoring: (String) -> Unit,
    onNavigateToNewMatch: () -> Unit,
    onNavigateToSpectator: () -> Unit
) {
    val liveMatches by viewModel.liveMatches.collectAsState()
    val allMatches by viewModel.allMatches.collectAsState()
    val tournaments by viewModel.allTournaments.collectAsState()

    var showNewTournamentDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(CricketGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SportsCricket,
                                contentDescription = "Logo",
                                tint = CricketBlueDark,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "CricScore Pro",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Tournament Scoring & Live Spectator",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    Button(
                        onClick = onNavigateToSpectator,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        modifier = Modifier.padding(end = 8.dp).testTag("header_spectator_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Podcasts,
                            contentDescription = "Spectator",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "Spectator Mode",
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNavigateToNewMatch,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_new_match")
            ) {
                Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = "New Match")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Match", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Hero Banner Card
            item {
                HeroBannerCard(
                    onNewMatch = onNavigateToNewMatch,
                    onSpectator = onNavigateToSpectator,
                    onNewTournament = { showNewTournamentDialog = true }
                )
            }

            // Live Matches Section
            if (liveMatches.isNotEmpty()) {
                item {
                    SectionHeader(title = "🔴 Live Tournament Matches", count = liveMatches.size)
                }

                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(liveMatches, key = { it.id }) { match ->
                            LiveMatchHomeCard(
                                match = match,
                                onScore = {
                                    viewModel.selectMatch(match.id)
                                    onNavigateToScoring(match.id)
                                },
                                onWatch = {
                                    viewModel.selectMatch(match.id)
                                    onNavigateToSpectator()
                                }
                            )
                        }
                    }
                }
            }

            // All / Completed Matches
            item {
                SectionHeader(title = "All Tournament Matches", count = allMatches.size)
            }

            val completedOrUpcoming = allMatches.filter { !it.status.startsWith("LIVE") && it.status != "INNINGS_BREAK" }
            if (completedOrUpcoming.isEmpty()) {
                item {
                    Text(
                        text = "No finished matches yet.",
                        modifier = Modifier.padding(horizontal = 16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(completedOrUpcoming, key = { it.id }) { match ->
                    MatchListItem(
                        match = match,
                        onClick = {
                            viewModel.selectMatch(match.id)
                            onNavigateToScoring(match.id)
                        }
                    )
                }
            }

            // Tournaments List
            item {
                SectionHeader(title = "Local Tournaments", count = tournaments.size)
            }

            items(tournaments, key = { it.id }) { tourn ->
                TournamentListItem(tournament = tourn)
            }

            item {
                Spacer(modifier = Modifier.height(64.dp))
            }
        }
    }

    if (showNewTournamentDialog) {
        CreateTournamentDialog(
            onDismiss = { showNewTournamentDialog = false },
            onCreate = { name, season, venue ->
                viewModel.createTournament(name, season, venue) {
                    showNewTournamentDialog = false
                }
            }
        )
    }
}

@Composable
private fun HeroBannerCard(
    onNewMatch: () -> Unit,
    onSpectator: () -> Unit,
    onNewTournament: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("hero_banner_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(CricketBluePrimary, CricketBlueDark)
                    )
                )
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "LOCAL TOURNAMENT SCORING",
                    color = CricketGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Professional Ball-by-Ball & Multi-Device Sync",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Score cricket matches with real-time wagon wheel, commentary, and broadcast live scoreboard to spectators on any device!",
                    color = Color(0xFFCBD5E1),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Action buttons
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onNewMatch,
                        colors = ButtonDefaults.buttonColors(containerColor = CricketGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("hero_start_match_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Start", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Start Match", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onSpectator,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        modifier = Modifier.testTag("hero_spectator_button")
                    ) {
                        Icon(Icons.Default.Podcasts, contentDescription = "Spectator", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Watch Live", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onNewTournament,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        modifier = Modifier.testTag("hero_new_tournament_button")
                    ) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = "Tournament", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tournament", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, count: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "$count",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun LiveMatchHomeCard(
    match: MatchEntity,
    onScore: () -> Unit,
    onWatch: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .clickable { onScore() }
            .testTag("live_match_card_${match.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).background(ScoreWicketRed, CircleShape))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("LIVE", color = ScoreWicketRed, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }

                Text(
                    text = "Code: ${match.matchCode}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = match.matchTitle,
                fontSize = 12.sp,
                color = CricketGold,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            Text(
                text = "${match.teamAName} vs ${match.teamBName}",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Innings ${match.currentInnings} in progress • ${match.overs} Ov",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onScore,
                    modifier = Modifier.weight(1f).height(38.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Score", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onWatch,
                    modifier = Modifier.weight(1f).height(38.dp)
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = "Watch", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Watch", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun MatchListItem(
    match: MatchEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable { onClick() }
            .testTag("match_item_${match.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = match.matchTitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "${match.overs} Ov",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${match.teamAName}  vs  ${match.teamBName}",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (match.status == "COMPLETED") {
                Text(
                    text = "🏆 ${match.winDescription.ifBlank { "${match.winner} Won" }}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF66BB6A)
                )
            } else {
                Text(
                    text = "Scheduled • Toss: ${if (match.tossWinnerTeam.isNotBlank()) "${match.tossWinnerTeam} chose to ${match.tossDecision}" else "Pending"}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TournamentListItem(tournament: TournamentEntity) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(CricketGold.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.EmojiEvents, contentDescription = "Trophy", tint = CricketGold)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(text = tournament.name, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = "${tournament.season} • ${tournament.venue}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun CreateTournamentDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, season: String, venue: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var season by remember { mutableStateOf("2026") }
    var venue by remember { mutableStateOf("City Cricket Ground") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Tournament", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Tournament Name") },
                    placeholder = { Text("e.g. Village Premier League") },
                    modifier = Modifier.fillMaxWidth().testTag("tournament_name_input"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = season,
                    onValueChange = { season = it },
                    label = { Text("Season / Year") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = venue,
                    onValueChange = { venue = it },
                    label = { Text("Ground / Venue") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onCreate(name, season, venue) },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("confirm_create_tournament_button")
            ) {
                Text("Create Tournament")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
