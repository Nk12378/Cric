package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FullMatchState
import com.example.data.model.InningsScoreSummary
import com.example.ui.theme.CricketGold

@Composable
fun ScorecardScreen(
    state: FullMatchState,
    modifier: Modifier = Modifier
) {
    val inn1 = state.innings1Summary
    val inn2 = state.innings2Summary

    var selectedInningsTab by remember {
        mutableIntStateOf(if (state.match.currentInnings == 2 && inn2 != null) 1 else 0)
    }

    val displayedInnings = if (selectedInningsTab == 0 || inn2 == null) inn1 else inn2

    Column(modifier = modifier.padding(horizontal = 16.dp)) {
        // Innings Tab Switcher
        if (inn2 != null) {
            TabRow(
                selectedTabIndex = selectedInningsTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("innings_tabs")
            ) {
                Tab(
                    selected = selectedInningsTab == 0,
                    onClick = { selectedInningsTab = 0 },
                    text = {
                        Text(
                            text = "${inn1.battingTeam} (${inn1.totalRuns}/${inn1.wickets})",
                            fontWeight = if (selectedInningsTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedInningsTab == 1,
                    onClick = { selectedInningsTab = 1 },
                    text = {
                        Text(
                            text = "${inn2.battingTeam} (${inn2.totalRuns}/${inn2.wickets})",
                            fontWeight = if (selectedInningsTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Batting Card
            item {
                BattingScorecardCard(innings = displayedInnings)
            }

            // Bowling Card
            item {
                BowlingScorecardCard(innings = displayedInnings)
            }

            // Fall of Wickets Card
            if (displayedInnings.fallOfWickets.isNotEmpty()) {
                item {
                    FallOfWicketsCard(innings = displayedInnings)
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun BattingScorecardCard(innings: InningsScoreSummary) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("batting_scorecard_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${innings.battingTeam} Batting",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${innings.totalRuns}/${innings.wickets} (${innings.oversFormatted} ov)",
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Column Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "BATTER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(2.4f)
                )
                Text(text = "R", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                Text(text = "B", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                Text(text = "4s", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                Text(text = "6s", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                Text(text = "SR", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.0f), textAlign = TextAlign.End)
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Batters list
            innings.batters.forEach { b ->
                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(2.4f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = b.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (b.isBatting) {
                                    Text(
                                        text = " *",
                                        color = CricketGold,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                            Text(
                                text = b.dismissal,
                                fontSize = 11.sp,
                                color = if (b.isOut) MaterialTheme.colorScheme.error else Color(0xFF66BB6A),
                                fontWeight = FontWeight.Normal
                            )
                        }

                        Text(
                            text = "${b.runs}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(0.7f),
                            textAlign = TextAlign.End
                        )
                        Text(
                            text = "${b.balls}",
                            fontSize = 13.sp,
                            modifier = Modifier.weight(0.7f),
                            textAlign = TextAlign.End,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                        Text(
                            text = "${b.fours}",
                            fontSize = 13.sp,
                            modifier = Modifier.weight(0.7f),
                            textAlign = TextAlign.End
                        )
                        Text(
                            text = "${b.sixes}",
                            fontSize = 13.sp,
                            modifier = Modifier.weight(0.7f),
                            textAlign = TextAlign.End
                        )
                        Text(
                            text = b.strikeRateFormatted,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1.0f),
                            textAlign = TextAlign.End,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    HorizontalDivider(
                        modifier = Modifier.padding(top = 6.dp),
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                    )
                }
            }

            // Extras & Total
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Extras",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${innings.extras.total} (wd ${innings.extras.wides}, nb ${innings.extras.noBalls}, b ${innings.extras.byes}, lb ${innings.extras.legByes})",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun BowlingScorecardCard(innings: InningsScoreSummary) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bowling_scorecard_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "${innings.bowlingTeam} Bowling",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Column Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "BOWLER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(2.4f)
                )
                Text(text = "O", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                Text(text = "M", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                Text(text = "R", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                Text(text = "W", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                Text(text = "ECON", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.0f), textAlign = TextAlign.End)
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Bowlers list
            innings.bowlers.forEach { bw ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = bw.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(2.4f)
                    )
                    Text(text = bw.oversFormatted, fontSize = 13.sp, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                    Text(text = "${bw.maidens}", fontSize = 13.sp, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                    Text(text = "${bw.runsConceded}", fontSize = 13.sp, modifier = Modifier.weight(0.7f), textAlign = TextAlign.End)
                    Text(
                        text = "${bw.wickets}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (bw.wickets > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(0.7f),
                        textAlign = TextAlign.End
                    )
                    Text(text = bw.economyFormatted, fontSize = 12.sp, modifier = Modifier.weight(1.0f), textAlign = TextAlign.End)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            }
        }
    }
}

@Composable
private fun FallOfWicketsCard(innings: InningsScoreSummary) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("fow_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Fall of Wickets",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            val fowText = innings.fallOfWickets.joinToString(",  ") { fow ->
                "${fow.teamScore}/${fow.wicketNumber} (${fow.batsmanName}, ${fow.overFormatted} ov)"
            }

            Text(
                text = fowText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 22.sp
            )
        }
    }
}
