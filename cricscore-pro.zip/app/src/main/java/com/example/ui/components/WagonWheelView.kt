package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BallEntity
import com.example.data.model.ShotZone
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.ScoreFourBlue
import com.example.ui.theme.ScoreSixPurple
import com.example.ui.theme.ScoreWicketRed
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun WagonWheelView(
    balls: List<BallEntity>,
    modifier: Modifier = Modifier,
    selectedZone: ShotZone? = null,
    onZoneSelected: ((ShotZone) -> Unit)? = null
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("wagon_wheel_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Wagon Wheel & Shot Zones",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Cricket Field Canvas
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .background(PitchGreen.copy(alpha = 0.85f), shape = CircleShape)
                    .testTag("wagon_wheel_canvas_box"),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .size(240.dp)
                        .testTag("wagon_wheel_canvas")
                ) {
                    val center = Offset(size.width / 2, size.height / 2)
                    val groundRadius = size.width / 2
                    val innerCircleRadius = groundRadius * 0.55f

                    // Boundary line
                    drawCircle(
                        color = Color.White.copy(alpha = 0.8f),
                        radius = groundRadius - 4f,
                        center = center,
                        style = Stroke(width = 2.5f)
                    )

                    // 30-yard fielding circle (dashed)
                    drawCircle(
                        color = Color.White.copy(alpha = 0.4f),
                        radius = innerCircleRadius,
                        center = center,
                        style = Stroke(
                            width = 1.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                        )
                    )

                    // Pitch rectangle in center
                    val pitchWidth = 14f
                    val pitchHeight = 44f
                    drawRect(
                        color = Color(0xFFD7CCC8), // Light clay/turf color
                        topLeft = Offset(center.x - pitchWidth / 2, center.y - pitchHeight / 2),
                        size = Size(pitchWidth, pitchHeight)
                    )

                    // Stumps at ends
                    drawLine(
                        color = Color(0xFF5D4037),
                        start = Offset(center.x - pitchWidth / 2 + 2, center.y - pitchHeight / 2 + 4),
                        end = Offset(center.x + pitchWidth / 2 - 2, center.y - pitchHeight / 2 + 4),
                        strokeWidth = 2f
                    )
                    drawLine(
                        color = Color(0xFF5D4037),
                        start = Offset(center.x - pitchWidth / 2 + 2, center.y + pitchHeight / 2 - 4),
                        end = Offset(center.x + pitchWidth / 2 - 2, center.y + pitchHeight / 2 - 4),
                        strokeWidth = 2f
                    )

                    // Draw shot rays
                    balls.forEach { ball ->
                        val zone = try {
                            ShotZone.valueOf(ball.shotZone)
                        } catch (e: Exception) {
                            ShotZone.STRAIGHT
                        }

                        // Angle in radians (0 is straight up, so subtract 90 deg)
                        val angleRad = Math.toRadians((zone.angleDegrees - 90.0))
                        val isBoundarySix = ball.runsScored == 6
                        val isBoundaryFour = ball.runsScored == 4
                        val isWicket = ball.isWicket

                        val rayLength = when {
                            isBoundarySix -> groundRadius * 0.95f
                            isBoundaryFour -> groundRadius * 0.88f
                            ball.runsScored >= 2 -> groundRadius * 0.65f
                            ball.runsScored == 1 -> groundRadius * 0.45f
                            isWicket -> groundRadius * 0.70f
                            else -> groundRadius * 0.25f
                        }

                        val rayColor = when {
                            isWicket -> ScoreWicketRed
                            isBoundarySix -> ScoreSixPurple
                            isBoundaryFour -> ScoreFourBlue
                            ball.runsScored > 0 -> Color(0xFFFFB300) // Gold
                            else -> Color.White.copy(alpha = 0.35f)
                        }

                        val endX = center.x + (rayLength * cos(angleRad)).toFloat()
                        val endY = center.y + (rayLength * sin(angleRad)).toFloat()

                        drawLine(
                            color = rayColor,
                            start = center,
                            end = Offset(endX, endY),
                            strokeWidth = if (isBoundarySix || isBoundaryFour) 3f else 1.8f
                        )

                        // Dot at end of shot ray
                        drawCircle(
                            color = rayColor,
                            radius = if (isBoundarySix || isBoundaryFour) 4f else 2.5f,
                            center = Offset(endX, endY)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Legend
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendItem(color = ScoreSixPurple, label = "6s")
                LegendItem(color = ScoreFourBlue, label = "4s")
                LegendItem(color = Color(0xFFFFB300), label = "1s-3s")
                LegendItem(color = ScoreWicketRed, label = "Wicket")
                LegendItem(color = Color.White.copy(alpha = 0.6f), label = "Dots")
            }

            // Zone Selection buttons (if selector enabled)
            if (onZoneSelected != null) {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Select Shot Zone:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                val zones = ShotZone.values()
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    zones.toList().chunked(3).forEach { rowZones ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            rowZones.forEach { zone ->
                                val isSelected = zone == selectedZone
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { onZoneSelected(zone) }
                                        .padding(vertical = 8.dp, horizontal = 4.dp)
                                        .testTag("zone_button_${zone.name.lowercase()}"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = zone.displayName.split(" / ").first(),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
