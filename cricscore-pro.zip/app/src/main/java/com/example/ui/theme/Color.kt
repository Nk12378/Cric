package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cricket Theme Color Palette
val CricketBluePrimary = Color(0xFF0F3E7A)
val CricketBlueDark = Color(0xFF071E3D)
val CricketGold = Color(0xFFFFB300)
val CricketGoldContainer = Color(0xFFFFE082)
val PitchGreen = Color(0xFF2E7D32)
val PitchGreenLight = Color(0xFF4CAF50)

val ScoreWicketRed = Color(0xFFD32F2F)
val ScoreSixPurple = Color(0xFF7B1FA2)
val ScoreFourBlue = Color(0xFF1976D2)
val ScoreDotGray = Color(0xFF757575)
val ScoreExtraOrange = Color(0xFFE65100)

val DarkSurface = Color(0xFF101924)
val DarkSurfaceVariant = Color(0xFF1B2838)
val DarkBackground = Color(0xFF0A1017)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF0F4F8)
val LightBackground = Color(0xFFF7F9FC)
