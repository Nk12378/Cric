package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BallEntity
import com.example.data.local.PlayerEntity
import com.example.data.model.FullMatchState
import com.example.data.model.ShotZone
import com.example.data.model.WicketType
import com.example.ui.components.CricketScoreboardHeader
import com.example.ui.theme.CricketBluePrimary
import com.example.ui.theme.CricketGold
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.ScoreDotGray
import com.example.ui.theme.ScoreExtraOrange
import com.example.ui.theme.ScoreFourBlue
import com.example.ui.theme.ScoreSixPurple
import com.example.ui.theme.ScoreWicketRed
import com.example.viewmodel.CricketViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScoringScreen(
    viewModel: CricketViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val matchState by viewModel.currentMatchState.collectAsState()
    val isServerRunning by viewModel.isServerRunning.collectAsState()
    val serverUrl by viewModel.serverUrl.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Scoring, 1: Scorecard, 2: Commentary, 3: Stats, 4: Broadcast

    // Dialog States
    var showWicketDialog by remember { mutableStateOf(false) }
    var showBowlerDialog by remember { mutableStateOf(false) }
    var showTossDialog by remember { mutableStateOf(false) }
    var showInningsBreakDialog by remember { mutableStateOf(false) }
    var showShotZoneDialog by remember { mutableStateOf(false) }

    var selectedShotZone by remember { mutableStateOf(ShotZone.STRAIGHT) }
    var playersForMatch by remember { mutableStateOf<List<PlayerEntity>>(emptyList()) }

    LaunchedEffect(matchState?.match?.id) {
        val id = matchState?.match?.id
        if (id != null) {
            playersForMatch = viewModel.getPlayersForMatch(id)
            if (matchState?.match?.status == "UPCOMING") {
                showTossDialog = true
            }
        }
    }

    // Auto-prompt bowler selection when an over completes and currentBowler is empty
    LaunchedEffect(matchState?.match?.currentBowlerName) {
        val state = matchState
        if (state != null && state.match.status.startsWith("LIVE") && state.match.currentBowlerName.isBlank()) {
            showBowlerDialog = true
        }
    }

    // Auto-prompt innings break
    LaunchedEffect(matchState?.match?.status) {
        if (matchState?.match?.status == "INNINGS_BREAK") {
            showInningsBreakDialog = true
        }
    }

    val state = matchState
    if (state == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Loading Match...")
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = state.match.matchTitle,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = "${state.match.teamAName} vs ${state.match.teamBName}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.undoLastBall() },
                        modifier = Modifier.testTag("undo_top_button")
                    ) {
                        Icon(imageVector = Icons.Default.Undo, contentDescription = "Undo Last Ball", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(
                        onClick = { selectedTab = 4 },
                        modifier = Modifier.testTag("broadcast_top_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Podcasts,
                            contentDescription = "Live Broadcast",
                            tint = if (isServerRunning) PitchGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Live Score Header (always visible at top of match)
            CricketScoreboardHeader(
                state = state,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                onShareClicked = { selectedTab = 4 }
            )

            // Tabs Row
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                edgePadding = 16.dp,
                modifier = Modifier.testTag("match_tabs")
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Scoring", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Scorecard", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Commentary", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Stats & Wagon", fontWeight = FontWeight.Bold) })
                Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("Spectator", fontWeight = FontWeight.Bold) })
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tab Content
            when (selectedTab) {
                0 -> LiveScoringKeypadSection(
                    state = state,
                    selectedShotZone = selectedShotZone,
                    onOpenShotZone = { showShotZoneDialog = true },
                    onOpenBowlerDialog = { showBowlerDialog = true },
                    onSwapStrike = { viewModel.swapStrike() },
                    onRunRecorded = { runs ->
                        viewModel.recordBall(
                            runs = runs,
                            extraType = "NONE",
                            extraRuns = 0,
                            isWicket = false,
                            wicketType = "NONE",
                            shotZone = selectedShotZone.name
                        )
                    },
                    onExtraRecorded = { extraType, extraRuns ->
                        viewModel.recordBall(
                            runs = 0,
                            extraType = extraType,
                            extraRuns = extraRuns,
                            isWicket = false,
                            wicketType = "NONE",
                            shotZone = selectedShotZone.name
                        )
                    },
                    onWicketClicked = { showWicketDialog = true },
                    onUndoClicked = { viewModel.undoLastBall() }
                )
                1 -> ScorecardScreen(state = state)
                2 -> LiveCommentaryScreen(state = state)
                3 -> MatchStatsScreen(state = state)
                4 -> SpectatorBroadcastScreen(
                    state = state,
                    isServerRunning = isServerRunning,
                    serverUrl = serverUrl,
                    onToggleBroadcast = { shouldStart ->
                        if (shouldStart) viewModel.startBroadcastServer(state.match.id)
                        else viewModel.stopBroadcastServer()
                    }
                )
            }
        }
    }

    // --- DIALOGS ---

    // 1. Wicket Dialog
    if (showWicketDialog) {
        WicketDismissalDialog(
            strikerName = state.match.strikerName,
            nonStrikerName = state.match.nonStrikerName,
            onDismiss = { showWicketDialog = false },
            onConfirm = { wicketType, fielderName, incomingBatterName ->
                showWicketDialog = false
                viewModel.recordBall(
                    runs = 0,
                    extraType = "NONE",
                    extraRuns = 0,
                    isWicket = true,
                    wicketType = wicketType.name,
                    fielder = fielderName,
                    shotZone = selectedShotZone.name,
                    newBatter = incomingBatterName
                )
            }
        )
    }

    // 2. Select Bowler Dialog
    if (showBowlerDialog) {
        SelectBowlerDialog(
            bowlingTeam = state.currentInningsSummary.bowlingTeam,
            previousBowler = state.match.previousBowlerName,
            existingBowlers = state.currentInningsSummary.bowlers.map { it.name },
            allPlayers = playersForMatch.filter { it.teamName == state.currentInningsSummary.bowlingTeam }.map { it.playerName },
            onDismiss = { showBowlerDialog = false },
            onBowlerSelected = { bowlerName ->
                showBowlerDialog = false
                viewModel.setBowler(bowlerName)
            }
        )
    }

    // 3. Toss & Opening Match Setup Dialog
    if (showTossDialog) {
        TossSetupDialog(
            teamA = state.match.teamAName,
            teamB = state.match.teamBName,
            onDismiss = { showTossDialog = false },
            onConfirm = { tossWinner, decision, striker, nonStriker, openingBowler ->
                showTossDialog = false
                viewModel.startMatch(
                    matchId = state.match.id,
                    tossWinner = tossWinner,
                    tossDecision = decision,
                    striker = striker,
                    nonStriker = nonStriker,
                    openingBowler = openingBowler
                )
            }
        )
    }

    // 4. Innings Break Dialog
    if (showInningsBreakDialog) {
        InningsBreakDialog(
            targetScore = state.target,
            battingTeam = if (state.match.bowlingFirstTeam.isNotBlank()) state.match.bowlingFirstTeam else state.match.teamBName,
            onDismiss = { showInningsBreakDialog = false },
            onStartInnings2 = { striker, nonStriker, openingBowler ->
                showInningsBreakDialog = false
                viewModel.startSecondInnings(state.match.id, striker, nonStriker, openingBowler)
            }
        )
    }

    // 5. Shot Zone Dialog
    if (showShotZoneDialog) {
        AlertDialog(
            onDismissRequest = { showShotZoneDialog = false },
            title = { Text("Select Shot Direction") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ShotZone.values().toList().chunked(2).forEach { row ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { zone ->
                                Button(
                                    onClick = {
                                        selectedShotZone = zone
                                        showShotZoneDialog = false
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (zone == selectedShotZone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                ) {
                                    Text(
                                        text = zone.displayName.split(" / ").first(),
                                        color = if (zone == selectedShotZone) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showShotZoneDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun LiveScoringKeypadSection(
    state: FullMatchState,
    selectedShotZone: ShotZone,
    onOpenShotZone: () -> Unit,
    onOpenBowlerDialog: () -> Unit,
    onSwapStrike: () -> Unit,
    onRunRecorded: (Int) -> Unit,
    onExtraRecorded: (String, Int) -> Unit,
    onWicketClicked: () -> Unit,
    onUndoClicked: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Crease Card: Striker, Non-striker, Bowler
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("crease_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Batsmen Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "BATTER",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            IconButton(onClick = onSwapStrike, modifier = Modifier.size(24.dp).testTag("swap_strike_button")) {
                                Icon(Icons.Default.SwapHoriz, contentDescription = "Swap Strike", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }

                        // Striker
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "* ${state.strikerStats?.name?.ifBlank { "Striker" }}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = CricketGold
                            )
                        }
                        Text(
                            text = "${state.strikerStats?.runs ?: 0} (${state.strikerStats?.balls ?: 0}) • 4s: ${state.strikerStats?.fours ?: 0}  6s: ${state.strikerStats?.sixes ?: 0}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Non-striker
                        Text(
                            text = state.nonStrikerStats?.name?.ifBlank { "Non-Striker" } ?: "Non-Striker",
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "${state.nonStrikerStats?.runs ?: 0} (${state.nonStrikerStats?.balls ?: 0})",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Bowler
                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "BOWLER",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            IconButton(onClick = onOpenBowlerDialog, modifier = Modifier.size(24.dp).testTag("change_bowler_button")) {
                                Icon(Icons.Default.Edit, contentDescription = "Change Bowler", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }

                        Text(
                            text = state.currentBowlerStats?.name?.ifBlank { "Select Bowler" } ?: "Select Bowler",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "${state.currentBowlerStats?.wickets ?: 0}-${state.currentBowlerStats?.runsConceded ?: 0} (${state.currentBowlerStats?.oversFormatted ?: "0.0"} ov)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Econ: ${state.currentBowlerStats?.economyFormatted ?: "0.00"}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Ongoing Over Timeline & Shot Zone indicator
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Timeline balls
                Column {
                    Text(
                        text = "This Over:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val currentOverBalls = state.currentInningsSummary.currentOverBalls
                        if (currentOverBalls.isEmpty()) {
                            Text("New over starting...", fontSize = 12.sp, color = Color.Gray)
                        } else {
                            currentOverBalls.forEach { b ->
                                OverBallBadge(ball = b)
                            }
                        }
                    }
                }

                // Shot direction chip
                OutlinedButton(
                    onClick = onOpenShotZone,
                    modifier = Modifier.testTag("shot_zone_button")
                ) {
                    Text(
                        text = "Zone: ${selectedShotZone.displayName.split(" / ").first()}",
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
            }
        }

        // SCORING KEYPAD
        Text(
            text = "Scoring Keypad",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Main Runs Row 1: 0, 1, 2, 3
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KeypadButton(text = "0", label = "Dot", modifier = Modifier.weight(1f), tag = "run_0") { onRunRecorded(0) }
            KeypadButton(text = "1", label = "Single", modifier = Modifier.weight(1f), tag = "run_1") { onRunRecorded(1) }
            KeypadButton(text = "2", label = "Double", modifier = Modifier.weight(1f), tag = "run_2") { onRunRecorded(2) }
            KeypadButton(text = "3", label = "Triple", modifier = Modifier.weight(1f), tag = "run_3") { onRunRecorded(3) }
        }

        // Main Runs Row 2: 4, 6, 5
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KeypadButton(
                text = "4",
                label = "FOUR!",
                bgColor = ScoreFourBlue,
                textColor = Color.White,
                modifier = Modifier.weight(1.2f),
                tag = "run_4"
            ) { onRunRecorded(4) }

            KeypadButton(
                text = "6",
                label = "SIXER!",
                bgColor = ScoreSixPurple,
                textColor = Color.White,
                modifier = Modifier.weight(1.2f),
                tag = "run_6"
            ) { onRunRecorded(6) }

            KeypadButton(text = "5", label = "Runs", modifier = Modifier.weight(0.8f), tag = "run_5") { onRunRecorded(5) }
        }

        // Extras Row: Wide, No Ball, Leg Bye, Bye
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KeypadButton(
                text = "WD",
                label = "+1 Extra",
                bgColor = ScoreExtraOrange.copy(alpha = 0.2f),
                textColor = ScoreExtraOrange,
                modifier = Modifier.weight(1f),
                tag = "extra_wd"
            ) { onExtraRecorded("WIDE", 1) }

            KeypadButton(
                text = "NB",
                label = "Free Hit",
                bgColor = ScoreExtraOrange.copy(alpha = 0.2f),
                textColor = ScoreExtraOrange,
                modifier = Modifier.weight(1f),
                tag = "extra_nb"
            ) { onExtraRecorded("NO_BALL", 1) }

            KeypadButton(
                text = "LB",
                label = "Leg Bye",
                bgColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.weight(1f),
                tag = "extra_lb"
            ) { onExtraRecorded("LEG_BYE", 1) }

            KeypadButton(
                text = "BYE",
                label = "Bye",
                bgColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.weight(1f),
                tag = "extra_bye"
            ) { onExtraRecorded("BYE", 1) }
        }

        // Big Action Buttons: WICKET & UNDO
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onWicketClicked,
                colors = ButtonDefaults.buttonColors(containerColor = ScoreWicketRed),
                modifier = Modifier
                    .weight(1.5f)
                    .height(52.dp)
                    .testTag("wicket_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("WICKET / OUT", fontWeight = FontWeight.Black, fontSize = 15.sp)
            }

            OutlinedButton(
                onClick = onUndoClicked,
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("undo_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Undo, contentDescription = "Undo", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Undo")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun KeypadButton(
    text: String,
    label: String,
    modifier: Modifier = Modifier,
    bgColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    textColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    tag: String = "",
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(58.dp)
            .clickable { onClick() }
            .testTag(tag),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = text,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = textColor
            )
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = textColor.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
private fun OverBallBadge(ball: BallEntity) {
    val (txt, bg) = when {
        ball.isWicket -> "W" to ScoreWicketRed
        ball.runsScored == 6 -> "6" to ScoreSixPurple
        ball.runsScored == 4 -> "4" to ScoreFourBlue
        ball.extraType == "WIDE" -> "${ball.extraRuns}wd" to ScoreExtraOrange
        ball.extraType == "NO_BALL" -> "${ball.runsScored + ball.extraRuns}nb" to ScoreExtraOrange
        ball.extraType == "BYE" -> "${ball.extraRuns}b" to ScoreExtraOrange
        ball.extraType == "LEG_BYE" -> "${ball.extraRuns}lb" to ScoreExtraOrange
        ball.runsScored > 0 -> "${ball.runsScored}" to Color(0xFF2E7D32)
        else -> "0" to ScoreDotGray
    }

    Box(
        modifier = Modifier
            .size(28.dp)
            .background(bg, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = txt,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun WicketDismissalDialog(
    strikerName: String,
    nonStrikerName: String,
    onDismiss: () -> Unit,
    onConfirm: (WicketType, String, String) -> Unit
) {
    var selectedType by remember { mutableStateOf(WicketType.BOWLED) }
    var fielderName by remember { mutableStateOf("") }
    var incomingBatter by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Wicket / Dismissal", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Dismissed Batter: $strikerName", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)

                Text("Dismissal Type:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                val types = listOf(WicketType.BOWLED, WicketType.CAUGHT, WicketType.LBW, WicketType.RUN_OUT, WicketType.STUMPED, WicketType.HIT_WICKET)
                types.chunked(3).forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { type ->
                            val isSel = type == selectedType
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedType = type }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = type.name.replace("_", " "),
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (selectedType == WicketType.CAUGHT || selectedType == WicketType.RUN_OUT || selectedType == WicketType.STUMPED) {
                    OutlinedTextField(
                        value = fielderName,
                        onValueChange = { fielderName = it },
                        label = { Text("Fielder Name") },
                        modifier = Modifier.fillMaxWidth().testTag("fielder_name_input"),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = incomingBatter,
                    onValueChange = { incomingBatter = it },
                    label = { Text("Next Incoming Batsman") },
                    placeholder = { Text("e.g. New Batter Name") },
                    modifier = Modifier.fillMaxWidth().testTag("next_batter_input"),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedType, fielderName, incomingBatter) },
                colors = ButtonDefaults.buttonColors(containerColor = ScoreWicketRed),
                modifier = Modifier.testTag("confirm_wicket_button")
            ) {
                Text("Confirm Wicket")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun SelectBowlerDialog(
    bowlingTeam: String,
    previousBowler: String,
    existingBowlers: List<String>,
    allPlayers: List<String>,
    onDismiss: () -> Unit,
    onBowlerSelected: (String) -> Unit
) {
    var customBowlerName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Next Bowler", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (previousBowler.isNotBlank()) {
                    Text(
                        text = "Previous bowler: $previousBowler (cannot bowl consecutive overs)",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Text("Available Bowling Options:", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                val candidateList = (existingBowlers + allPlayers).distinct().filter { it != previousBowler && it.isNotBlank() }

                candidateList.take(6).forEach { name ->
                    Button(
                        onClick = { onBowlerSelected(name) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(name, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedTextField(
                    value = customBowlerName,
                    onValueChange = { customBowlerName = it },
                    label = { Text("Or Enter Bowler Name") },
                    modifier = Modifier.fillMaxWidth().testTag("bowler_name_input"),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (customBowlerName.isNotBlank()) onBowlerSelected(customBowlerName)
                },
                enabled = customBowlerName.isNotBlank()
            ) {
                Text("Select")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun TossSetupDialog(
    teamA: String,
    teamB: String,
    onDismiss: () -> Unit,
    onConfirm: (tossWinner: String, decision: String, striker: String, nonStriker: String, openingBowler: String) -> Unit
) {
    var tossWinner by remember { mutableStateOf(teamA) }
    var decision by remember { mutableStateOf("BAT") }
    var striker by remember { mutableStateOf("Batsman 1") }
    var nonStriker by remember { mutableStateOf("Batsman 2") }
    var openingBowler by remember { mutableStateOf("Opening Bowler") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Start Match & Toss Details", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Who won the toss?", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = tossWinner == teamA, onClick = { tossWinner = teamA })
                        Text(teamA, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = tossWinner == teamB, onClick = { tossWinner = teamB })
                        Text(teamB, fontSize = 13.sp)
                    }
                }

                Text("Elected to:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = decision == "BAT", onClick = { decision = "BAT" })
                        Text("Bat First", fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = decision == "BOWL", onClick = { decision = "BOWL" })
                        Text("Bowl First", fontSize = 13.sp)
                    }
                }

                OutlinedTextField(
                    value = striker,
                    onValueChange = { striker = it },
                    label = { Text("Opening Striker") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = nonStriker,
                    onValueChange = { nonStriker = it },
                    label = { Text("Opening Non-Striker") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = openingBowler,
                    onValueChange = { openingBowler = it },
                    label = { Text("Opening Bowler") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(tossWinner, decision, striker, nonStriker, openingBowler) },
                modifier = Modifier.testTag("start_match_confirm_button")
            ) {
                Text("Start Match")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun InningsBreakDialog(
    targetScore: Int,
    battingTeam: String,
    onDismiss: () -> Unit,
    onStartInnings2: (striker: String, nonStriker: String, openingBowler: String) -> Unit
) {
    var striker by remember { mutableStateOf("Chaser 1") }
    var nonStriker by remember { mutableStateOf("Chaser 2") }
    var openingBowler by remember { mutableStateOf("Bowler 1") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Innings Break!", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "🎯 Target: $targetScore Runs for $battingTeam",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = CricketGold
                )
                Text("Enter opening batsmen and bowler for the 2nd innings chase:", fontSize = 13.sp)

                OutlinedTextField(
                    value = striker,
                    onValueChange = { striker = it },
                    label = { Text("Striker Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = nonStriker,
                    onValueChange = { nonStriker = it },
                    label = { Text("Non-Striker Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = openingBowler,
                    onValueChange = { openingBowler = it },
                    label = { Text("Opening Bowler Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onStartInnings2(striker, nonStriker, openingBowler) },
                modifier = Modifier.testTag("start_2nd_innings_button")
            ) {
                Text("Start 2nd Innings")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Later") }
        }
    )
}
