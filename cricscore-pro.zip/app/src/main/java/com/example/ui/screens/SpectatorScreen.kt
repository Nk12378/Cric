package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Search
import com.example.data.model.FullMatchState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MatchEntity
import com.example.ui.components.CricketScoreboardHeader
import com.example.ui.theme.CricketGold
import com.example.ui.theme.ScoreWicketRed
import com.example.viewmodel.CricketViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpectatorScreen(
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onWatchMatch: (String) -> Unit
) {
    BackHandler { onBack() }

    val liveMatches by viewModel.liveMatches.collectAsState()
    val allMatches by viewModel.allMatches.collectAsState()
    val matchState by viewModel.currentMatchState.collectAsState()
    val spectatorError by viewModel.spectatorErrorMessage.collectAsState()

    var matchCodeInput by remember { mutableStateOf("") }
    var selectedSpectatorTab by remember { mutableIntStateOf(0) } // 0: Live Board, 1: Scorecard, 2: Commentary, 3: Wagon Wheel

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(ScoreWicketRed, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Live Spectator Mode", fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Code Search Input Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("spectator_search_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Join Match by Code",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = matchCodeInput,
                            onValueChange = {
                                matchCodeInput = it.uppercase()
                                viewModel.clearSpectatorError()
                            },
                            placeholder = { Text("e.g. CRIC-7421") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("match_code_search_input"),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (matchCodeInput.isNotBlank()) {
                                    viewModel.findMatchByCode(matchCodeInput) { id ->
                                        onWatchMatch(id)
                                    }
                                }
                            },
                            modifier = Modifier.height(54.dp).testTag("join_match_button")
                        ) {
                            Icon(Icons.Default.Search, contentDescription = "Join")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Join")
                        }
                    }

                    if (spectatorError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = spectatorError ?: "",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // If a match is actively selected in Spectator Mode, display live spectator view
            val state = matchState
            if (state != null) {
                CricketScoreboardHeader(
                    state = state,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                TabRow(
                    selectedTabIndex = selectedSpectatorTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("spectator_tabs")
                ) {
                    Tab(selected = selectedSpectatorTab == 0, onClick = { selectedSpectatorTab = 0 }, text = { Text("Overview") })
                    Tab(selected = selectedSpectatorTab == 1, onClick = { selectedSpectatorTab = 1 }, text = { Text("Scorecard") })
                    Tab(selected = selectedSpectatorTab == 2, onClick = { selectedSpectatorTab = 2 }, text = { Text("Commentary") })
                    Tab(selected = selectedSpectatorTab == 3, onClick = { selectedSpectatorTab = 3 }, text = { Text("Wagon & Stats") })
                }

                Spacer(modifier = Modifier.height(8.dp))

                when (selectedSpectatorTab) {
                    0 -> SpectatorOverviewTab(state = state)
                    1 -> ScorecardScreen(state = state)
                    2 -> LiveCommentaryScreen(state = state)
                    3 -> MatchStatsScreen(state = state)
                }
            } else {
                // List of available matches to watch live
                Text(
                    text = "Live & Recent Matches",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                val displayMatches = (liveMatches + allMatches).distinctBy { it.id }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(displayMatches, key = { it.id }) { m ->
                        SpectatorMatchListItem(
                            match = m,
                            onClick = {
                                viewModel.selectMatch(m.id)
                                onWatchMatch(m.id)
                            }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SpectatorOverviewTab(state: FullMatchState) {
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Crease summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Batting Crease", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("* ${state.strikerStats?.name ?: "-"}", fontWeight = FontWeight.Bold, color = CricketGold)
                        Text("${state.strikerStats?.runs ?: 0} (${state.strikerStats?.balls ?: 0})", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(state.nonStrikerStats?.name ?: "-", fontWeight = FontWeight.Medium)
                        Text("${state.nonStrikerStats?.runs ?: 0} (${state.nonStrikerStats?.balls ?: 0})", fontWeight = FontWeight.Medium)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Current Bowler", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(state.currentBowlerStats?.name ?: "-", fontWeight = FontWeight.Bold)
                        Text("${state.currentBowlerStats?.wickets ?: 0}-${state.currentBowlerStats?.runsConceded ?: 0} (${state.currentBowlerStats?.oversFormatted ?: "0.0"} ov)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Recent balls timeline
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Recent Balls", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        state.recentBalls.takeLast(8).forEach { b ->
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(
                                        if (b.isWicket) ScoreWicketRed else if (b.runsScored >= 4) CricketGold else MaterialTheme.colorScheme.surface,
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (b.isWicket) "W" else "${b.runsScored + b.extraRuns}",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = if (b.isWicket) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SpectatorMatchListItem(
    match: MatchEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("spectator_match_${match.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = match.matchTitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Code: ${match.matchCode}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CricketGold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${match.teamAName} vs ${match.teamBName}",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (match.status.startsWith("LIVE")) "🔴 LIVE NOW" else if (match.status == "COMPLETED") "🏆 ${match.winDescription}" else "Scheduled (${match.overs} ov)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = if (match.status.startsWith("LIVE")) ScoreWicketRed else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
