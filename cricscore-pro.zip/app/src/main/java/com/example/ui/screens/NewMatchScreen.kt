package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CricketGold
import com.example.viewmodel.CricketViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewMatchScreen(
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onMatchCreated: (String) -> Unit
) {
    BackHandler { onBack() }

    val tournaments by viewModel.allTournaments.collectAsState()

    var matchTitle by remember { mutableStateOf("Tournament League Match") }
    var teamAName by remember { mutableStateOf("Royal Warriors") }
    var teamAShort by remember { mutableStateOf("RW") }
    var teamBName by remember { mutableStateOf("Golden Eagles") }
    var teamBShort by remember { mutableStateOf("GE") }
    var selectedOvers by remember { mutableIntStateOf(10) }
    var selectedTournamentId by remember {
        mutableStateOf(tournaments.firstOrNull()?.id ?: "tourn-ipl-local")
    }

    val oversOptions = listOf(5, 8, 10, 15, 20)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create New Match", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Tournament & Title
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Match Information",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        OutlinedTextField(
                            value = matchTitle,
                            onValueChange = { matchTitle = it },
                            label = { Text("Match Title / Stage") },
                            placeholder = { Text("e.g. Semi Final 1") },
                            modifier = Modifier.fillMaxWidth().testTag("match_title_input"),
                            singleLine = true
                        )

                        if (tournaments.isNotEmpty()) {
                            Text("Select Tournament:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                tournaments.take(3).forEach { tourn ->
                                    val isSel = tourn.id == selectedTournamentId
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(
                                                if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable { selectedTournamentId = tourn.id }
                                            .padding(vertical = 8.dp, horizontal = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = tourn.name,
                                            fontSize = 11.sp,
                                            maxLines = 1,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Teams Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Teams Setup",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        // Team A
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = teamAName,
                                onValueChange = { teamAName = it },
                                label = { Text("Team 1 Name") },
                                modifier = Modifier.weight(2f).testTag("team_a_name_input"),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = teamAShort,
                                onValueChange = { teamAShort = it },
                                label = { Text("Short") },
                                modifier = Modifier.weight(1f).testTag("team_a_short_input"),
                                singleLine = true
                            )
                        }

                        // Team B
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = teamBName,
                                onValueChange = { teamBName = it },
                                label = { Text("Team 2 Name") },
                                modifier = Modifier.weight(2f).testTag("team_b_name_input"),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = teamBShort,
                                onValueChange = { teamBShort = it },
                                label = { Text("Short") },
                                modifier = Modifier.weight(1f).testTag("team_b_short_input"),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            // Match Format & Overs
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Overs per Innings",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            oversOptions.forEach { ov ->
                                val isSelected = ov == selectedOvers
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { selectedOvers = ov }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${ov} Ov",
                                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                                        fontSize = 13.sp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        val maxBowlerOvers = (selectedOvers / 5).coerceAtLeast(1)
                        Text(
                            text = "Max overs per bowler: $maxBowlerOvers overs",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Submit Button
            item {
                Button(
                    onClick = {
                        val teamAPlayers = (1..11).map { "$teamAShort Player $it" }
                        val teamBPlayers = (1..11).map { "$teamBShort Player $it" }
                        val maxBowlerOvers = (selectedOvers / 5).coerceAtLeast(1)

                        viewModel.createMatch(
                            tournamentId = selectedTournamentId,
                            matchTitle = matchTitle,
                            teamA = teamAName,
                            teamB = teamBName,
                            teamAShort = teamAShort,
                            teamBShort = teamBShort,
                            overs = selectedOvers,
                            maxOversPerBowler = maxBowlerOvers,
                            teamAPlayers = teamAPlayers,
                            teamBPlayers = teamBPlayers,
                            onSuccess = { matchId ->
                                onMatchCreated(matchId)
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("create_match_submit_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(
                        text = "Create Match & Start Scoring",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
