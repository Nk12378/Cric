package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CricketGold,
    onPrimary = Color.Black,
    primaryContainer = CricketBluePrimary,
    onPrimaryContainer = Color.White,
    secondary = CricketGoldContainer,
    onSecondary = Color.Black,
    tertiary = PitchGreenLight,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5E1),
    error = ScoreWicketRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = CricketBluePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF),
    onPrimaryContainer = CricketBlueDark,
    secondary = CricketGold,
    onSecondary = Color.Black,
    secondaryContainer = CricketGoldContainer,
    onSecondaryContainer = Color(0xFF332000),
    tertiary = PitchGreen,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = Color(0xFF1E293B),
    surface = LightSurface,
    onSurface = Color(0xFF1E293B),
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Color(0xFF475569),
    error = ScoreWicketRed,
    onError = Color.White
)

@Composable
fun CricScoreTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
