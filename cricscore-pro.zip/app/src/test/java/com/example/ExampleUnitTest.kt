package com.example

import com.example.data.local.BallEntity
import com.example.data.model.CricketStatsCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testCricketStatsCalculatorBasicInnings() {
        val balls = listOf(
            BallEntity(
                matchId = "test-match",
                innings = 1,
                overNumber = 0,
                ballInOver = 1,
                isLegalBall = true,
                batsmanName = "Batter 1",
                bowlerName = "Bowler 1",
                nonStrikerName = "Batter 2",
                runsScored = 4,
                extraType = "NONE",
                extraRuns = 0,
                isWicket = false,
                wicketType = "NONE",
                dismissedPlayerName = ""
            ),
            BallEntity(
                matchId = "test-match",
                innings = 1,
                overNumber = 0,
                ballInOver = 2,
                isLegalBall = true,
                batsmanName = "Batter 1",
                bowlerName = "Bowler 1",
                nonStrikerName = "Batter 2",
                runsScored = 1,
                extraType = "NONE",
                extraRuns = 0,
                isWicket = false,
                wicketType = "NONE",
                dismissedPlayerName = ""
            ),
            BallEntity(
                matchId = "test-match",
                innings = 1,
                overNumber = 0,
                ballInOver = 3,
                isLegalBall = false,
                batsmanName = "Batter 2",
                bowlerName = "Bowler 1",
                nonStrikerName = "Batter 1",
                runsScored = 0,
                extraType = "WIDE",
                extraRuns = 1,
                isWicket = false,
                wicketType = "NONE",
                dismissedPlayerName = ""
            ),
            BallEntity(
                matchId = "test-match",
                innings = 1,
                overNumber = 0,
                ballInOver = 3,
                isLegalBall = true,
                batsmanName = "Batter 2",
                bowlerName = "Bowler 1",
                nonStrikerName = "Batter 1",
                runsScored = 6,
                extraType = "NONE",
                extraRuns = 0,
                isWicket = false,
                wicketType = "NONE",
                dismissedPlayerName = ""
            )
        )

        val summary = CricketStatsCalculator.calculateInningsSummary(
            innings = 1,
            battingTeam = "Team A",
            bowlingTeam = "Team B",
            balls = balls,
            strikerName = "Batter 2",
            nonStrikerName = "Batter 1",
            currentBowlerName = "Bowler 1"
        )

        assertEquals(12, summary.totalRuns) // 4 + 1 + 1 (wd) + 6
        assertEquals(0, summary.wickets)
        assertEquals(3, summary.legalBalls)
        assertEquals(1, summary.extras.wides)

        val b1 = summary.batters.find { it.name == "Batter 1" }
        assertNotNull(b1)
        assertEquals(5, b1!!.runs)
        assertEquals(2, b1.balls)
        assertEquals(1, b1.fours)

        val b2 = summary.batters.find { it.name == "Batter 2" }
        assertNotNull(b2)
        assertEquals(6, b2!!.runs)
        assertEquals(1, b2.balls)
        assertEquals(1, b2.sixes)

        val bowler = summary.bowlers.find { it.name == "Bowler 1" }
        assertNotNull(bowler)
        assertEquals(12, bowler!!.runsConceded)
        assertEquals(3, bowler.legalBalls)
        assertEquals("0.3", bowler.oversFormatted)
    }
}
